﻿namespace TcpipServerService.WorkLoad
{
    internal interface IWorkload
    {
        string Workload(string clientText);
    }
}