﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Threading;

using System.Data.SqlClient;

namespace TcpipServerService
{
    //public static class GlobalClass
    public class GlobalClass
    {
        public static StreamWriter sw;
        public static string gbl_server_client;
        public static string gbl_db_use;
        public static int gbl_file_console_flag;

        public GlobalClass(string ws_server_client, string ws_db_use, int ws_file_console_flag)
        {
            gbl_server_client = ws_server_client;
            gbl_db_use = ws_db_use;
            gbl_file_console_flag = ws_file_console_flag;
        }

        public static void WriteToFile(string Message)
        {
            Message = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " + Message;

            if (gbl_file_console_flag == 0)
            {
                //Display to Console
                Console.WriteLine(Message);
            }
            else
            {
                //string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
                string path = "c:\\8\\";
                

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                //string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\OODIS_Server_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                String file_prefix = "";
                if (gbl_db_use == "1")
                {
                    file_prefix = "DB";
                }
                string filepath = "c:\\8\\" + file_prefix + "OODIS_" + gbl_server_client + "_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                if (!File.Exists(filepath))
                {
                    // Create a file to write to.   
                    //using (StreamWriter sw = File.CreateText(filepath))
                    using (sw = File.CreateText(filepath))
                    {
                        sw.WriteLine(Message);
                        //sw.WriteLine(gbl_server_client);
                    }
                }
                else
                {
                    //using (StreamWriter sw = File.AppendText(filepath))
                    using (sw = File.AppendText(filepath))
                    {
                        sw.WriteLine(Message);
                    }
                }

                //sw.Flush();
            }
        }
    }
}
