﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Threading;

using System.Data.SqlClient;

namespace TcpipServerService
{
    static class Program
    {
        public static string[] cmd_parameters = new string[256];
        public static StreamWriter sw;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {           
            var list = new List<string>();
            Thread thread = Thread.CurrentThread;
            SqlConnection sql_connection;
            string ws_db_use;
            int ws_file_console_flag;

            //string ws_server_output_log = "c:\\8\\Redirect.txt";
            //string ws_client_output_log = "c:\\8\\Client_Redirect.txt";
            string ws_client_output_log = "c:\\8\\OODIS_Client_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            string ws_server_output_log = "c:\\8\\OODIS_Server_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            ws_db_use = "0";

            list.Add("SERVER");
            list.Add("CLIENT");

            if (args.Length == 0 || args[0] == "?" || !list.Contains(args[0].ToUpper()))
            {
                Console.WriteLine("Syntax :");
                Console.WriteLine("");
                Console.WriteLine("TcpipServerService server/client <options>");
                Console.WriteLine("");
                Console.WriteLine("Common options :");
                Console.WriteLine("-b, --processname__    Process Name");
                Console.WriteLine("-c, --ConnectString__      DB Connection String");
                //Console.WriteLine("-l, --logFileName__      Log file name (if none ==> console)");
                Console.WriteLine("-o, --output__      Output messages to console");
                Console.WriteLine("-t, --loggerThreshold__  Logger threshold (Error, Minimal, Debug)");
                Console.WriteLine("-p, --port__             TCP/IP port");
                Console.WriteLine("-z, --desktopid__        Desktop IDs");
                Console.WriteLine("");
                Console.WriteLine("server :");
                Console.WriteLine("-d, --dispatcher__               Dispatcher [Thread, Pool, Dynamic]Default=Thread");
                Console.WriteLine("-w, --workload__                 Workload [Echo, Time]Default=Echo");
                Console.WriteLine("-r, --realWork__                 True if server worker is CPU bound (real work), false if not (using thread.Sleep()) Default=false");
                Console.WriteLine("-i, --minTime__                  Minimal workload time in ms");
                Console.WriteLine("-x, --maxTime__                  Maximal workload time in ms");
                Console.WriteLine("-n, --numOfConcurentProceses__   Number of workers");
                Console.WriteLine("");
                Console.WriteLine("client :");
                Console.WriteLine("-a, --ipAddress__    TCP/IP address");                                
                Console.WriteLine("-f, --file__   Batch file to execute");
                Console.WriteLine("-m, --Method__         Client Method[Sync, Async, JS] Default=Sync");               
                Console.WriteLine("-n, --numOfClients__ Number of clients");
                Console.WriteLine("-o, --console__    Output messages to Console");
                Console.WriteLine("-u, --useThreads__   Use threads even for async clients");
                System.Environment.Exit(-1);
            }
            
            Options options = parseOptions(args);

            if (options.ServerVerb != null)
            {

                if (options.ServerVerb.DBConnectionString != "" && options.ServerVerb.DBConnectionString != null)
                {
                    string[] db_connect_string = options.ServerVerb.DBConnectionString.Split(':');

                    cmd_parameters[1] = db_connect_string[0]; //MS SQL database server
                    cmd_parameters[2] = db_connect_string[1]; //MS SQL user id
                    cmd_parameters[3] = db_connect_string[2]; //MS SQL password
                    cmd_parameters[4] = db_connect_string[3]; //MS SQL database name

                    sql_connection = connect_to_mssql();
                    SqlCommand command = new SqlCommand("Select Server_Output_log_file, Client_Output_log_file from [config_tbl]", sql_connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            ws_server_output_log = reader["Server_Output_log_file"].ToString().ToUpper();
                            ws_client_output_log = reader["Client_Output_log_file"].ToString().ToUpper();

                            ws_server_output_log = ws_server_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
                            ws_server_output_log = ws_server_output_log.Replace("MM", DateTime.Now.ToString("MM"));
                            ws_server_output_log = ws_server_output_log.Replace("DD", DateTime.Now.ToString("dd"));

                            ws_client_output_log = ws_client_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
                            ws_client_output_log = ws_client_output_log.Replace("MM", DateTime.Now.ToString("MM"));
                            ws_client_output_log = ws_client_output_log.Replace("DD", DateTime.Now.ToString("dd"));
                            //Console.WriteLine(String.Format("Server_Output_log_file {0}", reader["Server_Output_log_file"]));
                            ws_db_use = "1";
                        }
                    }
                    sql_connection.Close();
                }
            }
            else
            {
                //Client section
                if (options.ClientVerb.DBConnectionString != "")
                {
                    string[] db_connect_string = options.ClientVerb.DBConnectionString.Split(':');

                    cmd_parameters[1] = db_connect_string[0]; //MS SQL database server
                    cmd_parameters[2] = db_connect_string[1]; //MS SQL user id
                    cmd_parameters[3] = db_connect_string[2]; //MS SQL password
                    cmd_parameters[4] = db_connect_string[3]; //MS SQL database name

                    sql_connection = connect_to_mssql();
                    SqlCommand command = new SqlCommand("Select Server_Output_log_file, Client_Output_log_file from [config_tbl]", sql_connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            ws_server_output_log = reader["Server_Output_log_file"].ToString().ToUpper();
                            ws_client_output_log = reader["Client_Output_log_file"].ToString().ToUpper();

                            ws_server_output_log = ws_server_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
                            ws_server_output_log = ws_server_output_log.Replace("MM", DateTime.Now.ToString("MM"));
                            ws_server_output_log = ws_server_output_log.Replace("DD", DateTime.Now.ToString("dd"));

                            ws_client_output_log = ws_client_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
                            ws_client_output_log = ws_client_output_log.Replace("MM", DateTime.Now.ToString("MM"));
                            ws_client_output_log = ws_client_output_log.Replace("DD", DateTime.Now.ToString("dd"));
                            //Console.WriteLine(String.Format("Server_Output_log_file {0}", reader["Server_Output_log_file"]));
                            ws_db_use = "1";
                        }
                    }
                    //sql_connection.Close();

                }
            }

            if (args[0].ToUpper() == "SERVER")
            {
                new GlobalClass("SERVER", ws_db_use, 1);

                //Write the Console statement into file
                //temporary mask off
                //FileStream tfilestream = new FileStream(ws_server_output_log, FileMode.Append);
                //var tstreamwriter = new StreamWriter(tfilestream);
                //tstreamwriter.AutoFlush = true;
                //Console.SetOut(tstreamwriter);
                //Console.SetError(tstreamwriter);

                int mainThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId;

                TcpipServerService.GlobalClass.WriteToFile("Thread [" + mainThreadId.ToString() + "][Program]Server in Main " + args[0]);
                //Console.WriteLine("Thread [" + mainThreadId.ToString() + "][Program]Server in Main " + args[0]);
                //Console.WriteLine("[Program]Main [" + options.ServerVerb.DBConnectionString + "]");

                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                    new Service1(args)
                };

                ServiceBase.Run(ServicesToRun);

            }
            else
            {
                if (options.ClientVerb.Console.ToUpper() != "CONSOLE")
                {
                    //Write the Console statement into file
                    //temporary mask off
                    //FileStream filestream = new FileStream(ws_client_output_log, FileMode.Append);
                    //var streamwriter = new StreamWriter(filestream);
                    //streamwriter.AutoFlush = true;
                    //Console.SetOut(streamwriter);
                    //Console.SetError(streamwriter);
                    ws_file_console_flag = 1;
                }
                else
                {
                    ws_file_console_flag = 0;
                }

                new GlobalClass("CLIENT", ws_db_use, ws_file_console_flag);

                //CLIENT


                TcpipServerService.GlobalClass.WriteToFile("Thread [" + thread.ManagedThreadId.ToString() + "][Program]Client in Main " + args[0] + " [" + options.ClientVerb.ProcessName + "]");
                //Console.WriteLine("Thread ["+thread.ManagedThreadId.ToString()+ "][Program]Client in Main " + args[0] + " [" + options.ClientVerb.ProcessName + "]");

                Client.Runner clientRunner = new Client.Runner();

                if (options.ClientVerb.DBConnectionString != "")
                {
                    //Select from database

                    sql_connection = connect_to_mssql();
                    String desktop_id = options.ClientVerb.desktopid;
                    //Get timeout and other info from database
                    SqlCommand command = new SqlCommand("Select Desktop_Seq_no, task_seq_no, timeout, timeout_invoke_cnt, timeout_max_cnt, file_path from [task_tbl] where ltrim(rtrim(desktop_id)) = '" + desktop_id.Trim() + "' order by desktop_seq_no", sql_connection);

                    //Console.WriteLine("Client select timeout from task_tbl [" + command.CommandText + "]");
                    TcpipServerService.GlobalClass.WriteToFile("Client select timeout from task_tbl [" + command.CommandText + "]");

                    //Read thru task_tbl table
                    SqlDataReader timeout_reader = command.ExecuteReader();

                    string ws_timeout="";
                    Int64 ws_invoke_cnt = 0;
                    Int64 ws_max_cnt = 0;
                    int ws_desktop_seq_no = 0;
                    int ws_task_seq_no = 0;

                    //READ ALL THE TASKS FROM task_tbl TABLE BASED ON DESKTOP_ID
                    while (timeout_reader.Read())
                    {
                        ws_timeout = timeout_reader["timeout"].ToString();
                        ws_desktop_seq_no = Convert.ToInt16(timeout_reader["Desktop_Seq_no"]);
                        ws_task_seq_no = Convert.ToInt16(timeout_reader["task_Seq_no"]);
                        ws_invoke_cnt = Convert.ToInt64(timeout_reader["timeout_invoke_cnt"]);
                        ws_max_cnt = Convert.ToInt64(timeout_reader["timeout_max_cnt"]);
                        options.ClientVerb.BatchFile = Convert.ToString(timeout_reader["file_path"]);
                        clientRunner.Run(options, ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no);

                        TcpipServerService.GlobalClass.WriteToFile("[Program]Main finish running batch file");
                        //Console.WriteLine("[Program]Main finish running batch file");
                        clientRunner.End();

                        //temporary mask off
                        clientRunner = new Client.Runner();
                        //Wait for 1 sec
                        //Thread.Sleep(2000);
                    }
                    timeout_reader.Close();

                    /*
                    clientRunner.Run(options);
                    Console.WriteLine("SECOND TIME RUN clientRunner.Run\n");
                    clientRunner = new Client.Runner();
                    clientRunner.Run(options);
                    */
                }
                else
                {
                    //Client.Runner clientRunner = new Client.Runner();
                    clientRunner.Run(options, "-1", 0, 0, 0, 0);
                }

            }
        }

        private static Options parseOptions(string[] args)
        {
            string invokedVerb = null;
            object invokedVerbInstance = null;

            var options = new Options();
            if (!CommandLine.Parser.Default.ParseArgumentsStrict(args, options,
              (verb, subOptions) =>
              {
                  invokedVerb = verb;
                  invokedVerbInstance = subOptions;
              }))
            {
                Environment.Exit(CommandLine.Parser.DefaultExitCodeFail);
            }

            if (string.Compare(invokedVerb.ToLower(), "server", true) == 0)
            {
                options.Mode = Mode.Server;
                options.ServerVerb = invokedVerbInstance as ServerSubOptions;
            }
            else
            {
                options.Mode = Mode.Client;
                options.ClientVerb = invokedVerbInstance as ClientSubOptions;
            }

            return options;
        }

        private static SqlConnection connect_to_mssql()
        {
            // Build connection string
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            SqlConnection connection = null;

            if (cmd_parameters[1] != "")
            {
                builder.DataSource = cmd_parameters[1];
                builder.UserID = cmd_parameters[2];
                builder.Password = cmd_parameters[3];
                builder.InitialCatalog = cmd_parameters[4];

                try
                {
                    // Connect to SQL
                    Console.WriteLine("Connecting to SQL Server ... ");

                    string db_connect_str = "Server=" + cmd_parameters[1] + ";Database=" + cmd_parameters[4] + ";Trusted_Connection=Yes";
                    connection = new SqlConnection(db_connect_str);
                    {
                        connection.Open();
                        //Console.WriteLine("Done.");
                        Console.WriteLine("[" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss.fff tt") + "] Connection to database SUCCESS.");
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine(e.ToString());
                    //WriteToFile("Connection to database failed " + e.ToString());
                    Console.WriteLine("Connection to database failed " + e.ToString());
                }
            }
            return connection;
        }

    }
    
}
