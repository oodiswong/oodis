﻿using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Threading;

using System.Data.SqlClient;

namespace TcpipServerService.Logger
{
    internal class ConsoleLogger : BaseLogger, ILogger
    {
        private string gbl_server_log_file;
        private string gbl_client_log_file;
        private int gbl_server_client;
        private FileStream filestream;

        // The following constructor has parameters for two of the three 
        // properties. 
        public ConsoleLogger(string ws_server_log_file, string ws_client_log_file, int ws_server_client)
        {
            gbl_server_log_file = ws_server_log_file;
            gbl_client_log_file = ws_client_log_file;
            gbl_server_client = ws_server_client;
        }

        protected override void write(string line)
        {
            string ws_server_output_log;
            string ws_client_output_log;
            string ws_output_log;

            //Console.WriteLine("[consoleLogger]write [" + gbl_server_log_file + "][" + gbl_server_client.ToString() + "]");

            ws_server_output_log = gbl_server_log_file.ToUpper();
            ws_client_output_log = gbl_client_log_file.ToUpper();

            ws_server_output_log = ws_server_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
            ws_server_output_log = ws_server_output_log.Replace("MM", DateTime.Now.ToString("MM"));
            ws_server_output_log = ws_server_output_log.Replace("DD", DateTime.Now.ToString("dd"));

            ws_client_output_log = ws_client_output_log.Replace("YYYY", DateTime.Now.ToString("yyyy"));
            ws_client_output_log = ws_client_output_log.Replace("MM", DateTime.Now.ToString("MM"));
            ws_client_output_log = ws_client_output_log.Replace("DD", DateTime.Now.ToString("dd"));

            if (gbl_server_client == 1)
            {
                //Server
                ws_output_log = ws_server_output_log;
            }
            else
            {
                //client
                ws_output_log = ws_client_output_log;
            }
         
            try
            {
                filestream = new FileStream(ws_output_log, FileMode.Append);
            }
            catch (IOException)
            {
                //Console.WriteLine("filestrream is opened");
            }

            var streamwriter = new StreamWriter(filestream);
            streamwriter.AutoFlush = true;
            Console.SetOut(streamwriter);
            Console.SetError(streamwriter);

            Console.WriteLine("[consoleLogger]write [" + gbl_server_log_file + "][" + gbl_server_client.ToString() + "]");

            //if (this.compact)
            //    Console.Write(line);
            //else
                Console.WriteLine(line);

            //streamwriter.Close();
        }
    }
}