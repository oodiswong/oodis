﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using TcpipServerService.Logger;

namespace TcpipServerService.Client
{
    internal class Runner
    {
        private IClient client;

        public int Run(Options options, string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no)
        {
            init(options);
           
            Console.WriteLine("[Client][Runner]Run [" + this.clientOpt.Method.ToString() + "] timeout ["+ws_timeout+"][" + ws_desktop_seq_no.ToString()+"]");
            if (!this.clientOpt.UseThreads)
            {
                if (this.clientOpt.Method == ClientMethod.JS)
                    return this.runJS(ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no);
            }

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            Console.WriteLine("[Client][Runner]Run Batch file [" + this.clientOpt.BatchFile.ToString().Trim() + "]");

            batchfile_stream = new StreamReader(this.clientOpt.BatchFile);        

            if (this.clientOpt.Method == ClientMethod.Sync)
            {
                string text;

                Console.WriteLine("[Client][Runner]Run before start thread");

                Thread threads = new Thread(() =>
                {
                    text = "whoami";
                    //text = line;
                    //IClient client = this.createNewClient();
                    client = this.createNewClient();
                    client.Process(this.localEndPoint, this.logger, text, batchfile_stream, this.clientOpt.ProcessName, this.clientOpt.desktopid, ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no);
                });

                threads.Start();
                threads.Join();
            }
            else
            {
                //Need to sleep as wait for the previous thread to be finished.
                Thread.Sleep(2000);

                //Read the first line of text
                string line = batchfile_stream.ReadLine();
                string text;
                Console.WriteLine("method else");
                //Continue to read until you reach end of file
                while (line != null || batchfile_stream.Peek() != -1)
                {
                    //Console.WriteLine("[Client][Runner]line " + line);

                    Thread threads = new Thread(() =>
                    {
                        //text = $"whoami";
                        text = line;
                        //IClient client = this.createNewClient();
                        client = this.createNewClient();
                        client.Process(this.localEndPoint, this.logger, text, batchfile_stream, this.clientOpt.ProcessName, this.clientOpt.desktopid, ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no);
                    });

                    threads.Start();
                    threads.Join();
                    
                    //Read the next line
                    line = batchfile_stream.ReadLine();
                }

                batchfile_stream.Close();
                
            }

            //Console.WriteLine("Runtime in ms...");
            //this.logger.Log(LoggerThreshold.Debug, "RunTime in ms = "+stopWatch.ElapsedMilliseconds.ToString());
            TcpipServerService.GlobalClass.WriteToFile("RunTime in ms = " + stopWatch.ElapsedMilliseconds.ToString());
            return 0;
        }

        public void End()
        {
            Console.WriteLine("[Runner]End");
            client.End_Process();
        }

        private int runJS(string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            batchfile_stream = new StreamReader(this.clientOpt.BatchFile);

            //Read the first line of text
            string line = batchfile_stream.ReadLine();

            //Continue to read until you reach end of file
            while (line != null || batchfile_stream.Peek() != -1)
            {
                //Console.WriteLine("[Client][Runner][runJS]"+line);

                //CountdownEvent cde = new CountdownEvent(this.clientOpt.NumOfClients);
                //Here is MAX threads to fork out in JS
                CountdownEvent cde = new CountdownEvent(1);

                //string text = $"whoami";
                JSLikeASyncClient client = new JSLikeASyncClient();
                //client.Execute(this.localEndPoint, this.logger, text, (Exception ex, string value) =>
                client.Execute(this.localEndPoint, this.logger, line, this.clientOpt.ProcessName, this.clientOpt.desktopid, ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no, (Exception ex, string value) =>
                {
                    cde.Signal();
                });
                //MAX TIMEOUT
                cde.Wait(4000);
                //cde.Wait(Convert.(ws_timeout));

                //Read the next line
                line = batchfile_stream.ReadLine();
            }

            //this.logger.Log(LoggerThreshold.Debug, "RunTime in ms = "+stopWatch.ElapsedMilliseconds.ToString());
            TcpipServerService.GlobalClass.WriteToFile("RunTime in ms = " + stopWatch.ElapsedMilliseconds.ToString());
            return 0;
        }

        private void init(Options options)
        {
            this.options = options;
            this.clientOpt = this.options.ClientVerb;
            this.ipAddress = IPAddress.Parse(this.clientOpt.IPAddress);
            this.localEndPoint = new IPEndPoint(this.ipAddress, this.clientOpt.Port);
            //Console.WriteLine("[Client]Runner BatchFile [" + this.clientOpt.BatchFile + "]");

            if (this.clientOpt.BatchFile == "")
            {
                this.clientOpt.BatchFile = "test.txt";
            }
            //Console.WriteLine("[Client]Runner BatchFile [" + this.clientOpt.BatchFile + "]");

            Console.WriteLine("[Client]Runner CONSOLE [" + this.clientOpt.Console.ToString() + "]");

            //this.logger = (string.IsNullOrEmpty(this.clientOpt.LogFileName)) ?
            /*
            if (string.IsNullOrEmpty(this.clientOpt.Console))
            {
                this.logger = (ILogger)(new ConsoleLogger("c:\\8\\DBOODIS_Server_Log_yyyymmdd.txt", "c:\\8\\DBOODIS_Client_Log_yyyymmdd.txt", 2));
            }
            else
            {
                this.logger = (this.clientOpt.Console.ToUpper() == "CONSOLE") ?
                  (ILogger)(new ConsoleLogger("c:\\8\\DBOODIS_Server_Log_yyyymmdd.txt", "c:\\8\\DBOODIS_Client_Log_yyyymmdd.txt", 2)) :
                  (ILogger)(new FileLogger("", "c:\\8\\DBOODIS_Server_Log_yyyymmdd.txt", "c:\\8\\DBOODIS_Client_Log_yyyymmdd.txt", 2));
                  //(ILogger)(new FileLogger(this.clientOpt.LogFileName, "c:\\8\\DBOODIS_Server_Log_yyyymmdd.txt", "c:\\8\\DBOODIS_Client_Log_yyyymmdd.txt", 2));
                //this.logger.LogThreshold = this.clientOpt.LoggerThreshold;
            }
            */
        }

        private IClient createNewClient()
        {
            //switch (this.clientOpt.Flow)
            switch (this.clientOpt.Method)
            {
                //case ClientFlow.Sync:
                case ClientMethod.Sync:
                    return new SyncClient();

                //case ClientFlow.Async:
                case ClientMethod.Async:
                    return new ClasicASyncClient();

                //case ClientFlow.JS:
                case ClientMethod.JS:
                    return new JSLikeASyncClient();

                default:
                    //return new NewASyncClient();
                    return new SyncClient();
            }
        }

        private Options options;
        private ClientSubOptions clientOpt;
        private IPAddress ipAddress;
        private IPEndPoint localEndPoint;
        private ILogger logger;
        private StreamReader batchfile_stream;
    }
}