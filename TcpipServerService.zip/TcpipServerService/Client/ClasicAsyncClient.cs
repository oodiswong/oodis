﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using TcpipServerService.Logger;
//using TcpipServerService.Service1;
using TcpipServerService;

using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace TcpipServerService.Client
{
    internal class ClasicASyncClient : IClient
    {
        public static RunResults RunExecutable(string executablePath, string arguments, string workingDirectory)
        {
            RunResults runResults = new RunResults
            {
                Output = new StringBuilder(),
                Error = new StringBuilder(),
                RunException = null
            };

            try
            {
                if (File.Exists(executablePath))
                {
                    using (Process proc = new Process())
                    {
                        proc.StartInfo.FileName = executablePath;
                        proc.StartInfo.Arguments = '"' + arguments + '"';
                        proc.StartInfo.WorkingDirectory = workingDirectory;
                        proc.StartInfo.UseShellExecute = false;
                        proc.StartInfo.RedirectStandardOutput = true;
                        proc.StartInfo.RedirectStandardError = true;
                        proc.OutputDataReceived += (o, e) => runResults.Output.Append(e.Data).Append(Environment.NewLine);
                        proc.ErrorDataReceived += (o, e) => runResults.Error.Append(e.Data).Append(Environment.NewLine);

                        proc.Start();
                        proc.BeginOutputReadLine();
                        proc.BeginErrorReadLine();
                        proc.WaitForExit();
                        runResults.ExitCode = proc.ExitCode;
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid executable path.", "executablePath");
                }
            }
            catch (Exception e)
            {
                runResults.RunException = e;
            }

            return runResults;

        }

        public string Process(IPEndPoint localEndPoint, ILogger logger, string ws_text, StreamReader file_ptr, string processname, string desktopid, string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no)
        {
            this.logger = logger;

            TcpClient client = new TcpClient();
            AsyncClientState cs = null;

            //Read the first line of text
            //string line = file_ptr.ReadLine();

            Byte[] bytes = new byte[2560];
            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();

            client.Connect(localEndPoint);
            string local_ip = client.Client.LocalEndPoint.ToString();
            string rmt_ip = client.Client.RemoteEndPoint.ToString();

            //print_log(logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client connected to server [" + rmt_ip + "]");
            print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client connected to server [" + rmt_ip + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip+"T"+ thread_id + "] ClasicAsyncclient Client connected to server [" + rmt_ip + "]");

            try
            {
                IAsyncResult readResult;
                IAsyncResult writeResult;
                //Unmask for method Async
                //Continue to read until you reach end of file
                //while (line != null || file_ptr.Peek() != -1)
                //{
                    //Console.WriteLine("[AsyncClient]line [" + text + "]");
                    //logger.Cache(LoggerThreshold.Debug, "[AsyncClient]line [" + ws_text + "]");
                    //print_log(logger, " [AsyncClient]line [" + ws_text + "]");
                    print_log("[AsyncClient]line [" + ws_text + "]");

                    //Write process name + desktopid + timeout + invoke_cnt + max_cnt + desktop_seq_no to + task_seq_no server
  
                    cs = new AsyncClientState(client.GetStream(), processname + "_" + desktopid +"_" + ws_timeout + "_" + ws_invoke_cnt.ToString() + "_" + ws_max_cnt.ToString() + "_" + ws_desktop_seq_no.ToString() + "_" + ws_task_seq_no.ToString() + "\n");
                    //writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, new AsyncCallback(this.writeCallback), cs);
                    writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, null, null);
                    cs.NetStream.EndWrite(writeResult);

                    cs = new AsyncClientState(client.GetStream(), ws_text+"\n");
                    //writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, new AsyncCallback(this.writeCallback), cs);
                    writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, null, null);
                    cs.NetStream.EndWrite(writeResult);

                    //writeResult.AsyncWaitHandle.WaitOne();
                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T"+thread_id + "] ClasicAsyncclient Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");
                    //print_log(logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");
                    print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");
                    //Console.WriteLine("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");

                    string[] cmd_line_arg = ws_text.Split(new char[] { ' ' }, 3);
                    //string[] cmd_line_arg = ws_text.Split(' ');
                    String org_dir_file;
                    int ws_cnt=1;

                    switch (cmd_line_arg[0])
                    {
                        case "sleep":
                            //Console.WriteLine("SleepFunc [" + cmd_line_arg[1] + "]");
                            string ws_rmt_info = client.Client.RemoteEndPoint.ToString();

                            int ws_sleep_sec = Int32.Parse(cmd_line_arg[1]);

                            //Console.WriteLine("SleepFunc " + ws_sleep_sec.ToString());
                            Thread.Sleep(ws_sleep_sec);
                            break;
                        case "whoami":
                            readResult = cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (first_readCallback) =>
                            {
                                try
                                {
                                    int bytesRead0 = cs.NetStream.EndRead(first_readCallback);
                                    cs.AppendResponse(bytesRead0);

                                    if (cs.NetStream.DataAvailable)
                                        cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (asyncReadResult) =>
                                        {
                                            try
                                            {
                                                AsyncClientState cs1 = (AsyncClientState)asyncReadResult.AsyncState;

                                                int bytesRead1 = cs1.NetStream.EndRead(asyncReadResult);
                                                cs1.AppendResponse(bytesRead1);

                                                if (cs1.NetStream.DataAvailable)
                                                {
                                                    //cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);
                                                }
                                                else
                                                {
                                                    //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    this.ReadDone.Set();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                //print_log(logger, ex.ToString());
                                                print_log(ex.ToString());
                                                //logger.Log(LoggerThreshold.Error, ex.ToString());
                                            }
                                        }, null);
                                    else
                                    {
                                        //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        this.ReadDone.Set();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //print_log(logger, ex.ToString());
                                    print_log(ex.ToString());
                                    //logger.Log(LoggerThreshold.Error, ex.ToString());
                                }
                            }, null);

                            this.ReadDone.WaitOne();
                            break;
                        case "runbatch":
                            //Console.WriteLine("[ClasicasyncClient]Process runbatch");
                            //print_log(logger, " [ClasicasyncClient]Process runbatch");
                            print_log("[ClasicasyncClient]Process runbatch");
                            //readResult = cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);

                            readResult = cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (first_readCallback) =>
                            {
                                try
                                {
                                    int bytesRead0 = cs.NetStream.EndRead(first_readCallback);
                                    cs.AppendResponse(bytesRead0);

                                    if (cs.NetStream.DataAvailable)
                                        cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (asyncReadResult) =>
                                        {
                                            try
                                            {
                                                AsyncClientState cs1 = (AsyncClientState)asyncReadResult.AsyncState;

                                                int bytesRead1 = cs1.NetStream.EndRead(asyncReadResult);
                                                cs1.AppendResponse(bytesRead1);

                                                if (cs1.NetStream.DataAvailable)
                                                {
                                                    //cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);
                                                }
                                                else
                                                {
                                                    //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    this.ReadDone.Set();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                //print_log(logger, ex.ToString());
                                                print_log(ex.ToString());
                                                //logger.Log(LoggerThreshold.Error, ex.ToString());
                                            }

                                        }, null);
                                    else
                                    {
                                        //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        this.ReadDone.Set();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //print_log(logger, ex.ToString());
                                    print_log(ex.ToString());
                                    //logger.Log(LoggerThreshold.Error, ex.ToString());
                                }
                            }, null);

                            this.ReadDone.WaitOne();
                            break;
                        case "local_runbatch":

                            //batch or executable filename
                            string[] batch_exe = cmd_line_arg[2].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                            string[] the_rest = new string[batch_exe.Length - 1];
                            Console.WriteLine(" batch_exe " + string.Join(",", batch_exe));

                            //the rest
                            Array.Copy(batch_exe, 1, the_rest, 0, batch_exe.Length - 1);
                            Console.WriteLine(" the_rest " + string.Join(",", the_rest));

                            //argumnts[0] = tmp1[1];
                            //argumnts[1] = batch_exe[0];
                            //argumnts[2] = the_rest[0];

                            string lcl_run_result;
                            RunResults runResults = RunExecutable(batch_exe[0], the_rest[0], ".");
                            //RunResults runResults = RunExecutable(command_main, cmd_line_arg[1] + " " + cmd_line_arg[2], ".");
                            if (runResults.RunException != null)
                            {
                                //Console.WriteLine(runResults.RunException);
                                lcl_run_result = runResults.RunException.ToString();
                            }
                            else
                            {
                                //Console.WriteLine("Output");
                                //Console.WriteLine("======");
                                //Console.WriteLine(runResults.Output);
                                //Console.WriteLine("Error");
                                //Console.WriteLine("=====");
                                //Console.WriteLine(runResults.Error);
                                lcl_run_result = runResults.Output.ToString();
                            }

                            //var writeBuffer = Encoding.UTF8.GetBytes(lcl_run_result);

                            cs = new AsyncClientState(client.GetStream(), lcl_run_result + "\n");
                            //Console.WriteLine("local_runbatch function");
                            //this.logger.Cache(LoggerThreshold.Debug, "local_runbatch function [" + cs.WriteBuffer.Length.ToString() + "]");
                            //writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, new AsyncCallback(this.writeCallback), cs);
                            //cs.NetStream.Write(cs.WriteBuffer, 0, cs.WriteBuffer.Length);

                            //writeResult.AsyncWaitHandle.WaitOne();
                            //cs.NetStream.Flush();

                            writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, null, null);
                            cs.NetStream.EndWrite(writeResult);

                            //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient local_runbatch Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");
                            print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient local_runbatch Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");
                            //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient local_runbatch Client wrote [" + cs.Input.Trim() + "] to [" + rmt_ip + "]");

                            //}

                            //Read the next line
                            //line = file_ptr.ReadLine();
                            //}
                            break;

                        case "server_transfer":
                            //get file from server and write to client system

                            string[] st_cmd_line_arg = ws_text.Split(new char[] { ' ' }, 2);

                            //batch or executable filename
                            string[] source_file = st_cmd_line_arg[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                            Console.WriteLine("[ClasicAsyncClient]server_transfer [" + string.Join(",", source_file) + "]");

                            //Byte[] sbytes = new byte[2560];
                            //string ws_rmt_info = client.Client.RemoteEndPoint.ToString();
                            NetworkStream st_netStream = client.GetStream();
                            //Syntax : server_transfer <server directory/file> <client remote directory/file>

                            //org_dir_file = cmd_line_arg[1];
                            org_dir_file = source_file[2];
                            //-----          
                            var ms = new MemoryStream();
                            byte[] data = new byte[1024];
                            int numBytesRead;
                            long total_sizes = 0;
                            string data_str;

                            ws_cnt = 1;
                            do
                            {
                                numBytesRead = st_netStream.Read(data, 0, data.Length);
                                data_str = Encoding.Default.GetString(data);

                                Console.Write("[" + ws_cnt.ToString() + "]");
                                ws_cnt = ws_cnt + 1;

                                if (data_str.Contains("THEEND"))
                                {
                                    ms.Write(data, 0, numBytesRead - 7);
                                    total_sizes = total_sizes + numBytesRead - 7;
                                    break;
                                }

                                total_sizes = total_sizes + numBytesRead;
                                ms.Write(data, 0, numBytesRead);
                            } while (numBytesRead == data.Length);

                            //Write the file to local system
                            using (FileStream file = new FileStream(org_dir_file, FileMode.Create, System.IO.FileAccess.Write))
                            {
                                ms.WriteTo(file);
                                ms.Close();
                            }
                            break;
                        case "client_transfer":
                            Thread.Sleep(50);

                            string[] ct_cmd_line_arg = ws_text.Split(new char[] { ' ' }, 2);

                            //batch or executable filename
                            string[] ct_source_file = ct_cmd_line_arg[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                            Console.WriteLine("[ClasicAsyncClient]client_transfer [" + string.Join(",", ct_source_file) + "]");
                            //Read the local file and wrote to server
                            try
                            {
                                //org_dir_file = cmd_line_arg[1];
                                org_dir_file = ct_source_file[0];
                                NetworkStream ct_netStream = client.GetStream();

                                ws_cnt = 1;
                                using (BinaryReader b = new BinaryReader(
                                File.Open(org_dir_file, FileMode.Open)))
                                {
                                    // 2.
                                    // Position and length variables.
                                    int pos = 0;
                                    // 2A.
                                    // Use BaseStream.
                                    int length = (int)b.BaseStream.Length;
  
                                    while (pos < length)
                                    {
                                        byte[] lcl_input = b.ReadBytes(20480);
                                        //logger.Cache(LoggerThreshold.Debug, "read from file [" + Encoding.UTF8.GetString(v) + "]");
                                        //netstream.Write(v, 0, v.Length);
                                        //cs = new AsyncClientState(client.GetStream(), ByteArrayToString(lcl_input));
                                        //writeResult = cs.NetStream.BeginWrite(cs.WriteBuffer, 0, cs.WriteBuffer.Length, null, null);
                                        //cs.NetStream.EndWrite(writeResult);
                                        ct_netStream.Write(lcl_input, 0, lcl_input.Length);
                                        Console.Write("[" + ws_cnt.ToString() + "]");
                                        ws_cnt = ws_cnt + 1;
                                        //obj1.Write(v, 0, v.Length);
                                        // 4.
                                        // Advance our position variable.
                                        pos += lcl_input.Length;
                                        Thread.Sleep(50);
                                    }

                                    Thread.Sleep(50);
                                    byte[] theend = Encoding.UTF8.GetBytes("THEEND\n"); ;
                                    ct_netStream.Write(theend, 0, theend.Length);
                                    ct_netStream.Flush();
                                    Thread.Sleep(5540);

                                    //print_log(this.logger, " Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                                    print_log("Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                                    //logger.Cache(LoggerThreshold.Debug, "Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                                }
                            }
                            catch (Exception read_err)
                            {
                                //print_log(this.logger, " [ClasicAsyncClient]Process client_transfer err " + read_err.ToString());
                                print_log("[ClasicAsyncClient]Process client_transfer err " + read_err.ToString());
                                //logger.Cache(LoggerThreshold.Debug, "[ClasicAsyncClient]Process client_transfer err " + read_err.ToString());
                            }
                            client.Close();
                            break;

                        default:
                            readResult = cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (first_readCallback) =>
                            {
                                try
                                {
                                    int bytesRead0 = cs.NetStream.EndRead(first_readCallback);
                                    cs.AppendResponse(bytesRead0);

                                    if (cs.NetStream.DataAvailable)
                                        cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (asyncReadResult) =>
                                        {
                                            try
                                            {
                                                AsyncClientState cs1 = (AsyncClientState)asyncReadResult.AsyncState;

                                                int bytesRead1 = cs1.NetStream.EndRead(asyncReadResult);
                                                cs1.AppendResponse(bytesRead1);

                                                if (cs1.NetStream.DataAvailable)
                                                {
                                                    //cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);
                                                }
                                                else
                                                {
                                                    //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs1.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                                    this.ReadDone.Set();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                //print_log(logger, ex.ToString());
                                                print_log(ex.ToString());
                                                //logger.Log(LoggerThreshold.Error, ex.ToString());
                                            }
                                        }, null);
                                    else
                                    {
                                        //print_log(this.logger, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client readCallback get [" + cs.Response.ToString().Trim() + "] from [" + rmt_ip + "]");
                                        this.ReadDone.Set();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //print_log(logger, ex.ToString());
                                    print_log(ex.ToString());
                                    //logger.Log(LoggerThreshold.Error, ex.ToString());
                                }
                            }, null);

                            this.ReadDone.WaitOne();
                            break;
                    }
            }
            catch (Exception ex)
            {
                string err_msg = ex.ToString();

                //print_log(logger, " Process 1 Catch [" + ex.ToString() + "]");
                print_log("Process 1 Catch [" + ex.ToString() + "]");
                //logger.Cache(LoggerThreshold.Error, "Process 1 Catch [" + ex.ToString() + "]");

                if (!err_msg.Contains("aborted by the software in your host machine"))
                {
                    //print_log(logger, " Process Catch [" + ex.ToString() + "]");
                    print_log("Process Catch [" + ex.ToString() + "]");
                    //logger.Cache(LoggerThreshold.Error, "Process Catch [" + ex.ToString() + "]");
                }
            }

            if ((cs != null) && (cs.NetStream != null)) cs.NetStream.Close();
            if (client.Connected) client.Close();
            //print_log(logger, " Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client disconected from server [" + rmt_ip + "]");
            print_log("Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client disconected from server [" + rmt_ip + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] ClasicAsyncclient Client disconected from server [" + rmt_ip + "]");
            //logger.Flush();

            return (cs != null) ? cs.Response.ToString() : string.Empty;
        }

        public void End_Process()
        {
        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        private void writeCallback(IAsyncResult asyncResult)
        {
            //logger.Cache(LoggerThreshold.Debug, "[ClasicAsyncClient]writeCallback");
            //print_log(logger, " [ClasicAsyncClient]writeCallback");
            print_log("[ClasicAsyncClient]writeCallback");
            try
            {
                AsyncClientState cs = (AsyncClientState)asyncResult.AsyncState;
                cs.NetStream.EndWrite(asyncResult);
            }
            catch (Exception ex)
            {
                this.logger.Log(LoggerThreshold.Error, ex.ToString());
            }
        }

        private void readCallback(IAsyncResult asyncResult)
        {
            try
            {
                AsyncClientState cs = (AsyncClientState)asyncResult.AsyncState;
                
                int bytesRead = cs.NetStream.EndRead(asyncResult);
                cs.AppendResponse(bytesRead);
                
                if (cs.NetStream.DataAvailable)
                    //cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);
                    cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, (asyncReadResult) =>
                    {
                        try
                        {
                            AsyncClientState cs1 = (AsyncClientState)asyncResult.AsyncState;

                            int bytesRead1 = cs1.NetStream.EndRead(asyncResult);
                            cs1.AppendResponse(bytesRead1);

                            if (cs1.NetStream.DataAvailable)
                            {
                                //cs.NetStream.BeginRead(cs.ReadBuffer, 0, cs.ReadBuffer.Length, new AsyncCallback(this.readCallback), cs);
                            }
                            else
                            {
                                //print_log(this.logger, " [ClasicAsyncClient]readCallback get [" + cs1.Response.ToString().Trim() + "]");
                                print_log("[ClasicAsyncClient]readCallback get [" + cs1.Response.ToString().Trim() + "]");
                                //this.logger.Cache(LoggerThreshold.Debug, "[ClasicAsyncClient]readCallback get [" + cs1.Response.ToString().Trim() + "]");
                                this.ReadDone.Set();
                            }
                        }
                        catch (Exception ex)
                        {
                            //print_log(logger, ex.ToString());
                            print_log(ex.ToString());
                            //logger.Log(LoggerThreshold.Error, ex.ToString());
                        }

                    }, null) ;
                else
                {
                    //print_log(this.logger, " [ClasicAsyncClient]readCallback get [" + cs.Response.ToString().Trim() + "]");
                    print_log("[ClasicAsyncClient]readCallback get [" + cs.Response.ToString().Trim() + "]");
                    //this.logger.Cache(LoggerThreshold.Debug, "[ClasicAsyncClient]readCallback get [" + cs.Response.ToString().Trim() + "]");
                    this.ReadDone.Set();
                }
            }
            catch (Exception ex)
            {
                //print_log(logger, ex.ToString());
                print_log(ex.ToString());
                //logger.Log(LoggerThreshold.Error, ex.ToString());
            }
        }

        //private static void print_log(ILogger logger, string ws_print_str)
        private static void print_log(string ws_print_str)
        {
            //var time = DateTime.Now;
            //string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");
            //logger.Cache(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);
            TcpipServerService.GlobalClass.WriteToFile(ws_print_str);
        }

        private ILogger logger;
        private ManualResetEvent ReadDone = new ManualResetEvent(false);        
    }
}