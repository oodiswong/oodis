﻿using System.IO;
using System.Net;
using TcpipServerService.Logger;

namespace TcpipServerService.Client
{
    internal interface IClient
    {
        string Process(IPEndPoint localEndPoint, ILogger logger, string text, StreamReader file_ptr, string processname, string desktopid, string ws_timeout, long ws_invoke_cnt, long ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no);
        void End_Process();
    }
}