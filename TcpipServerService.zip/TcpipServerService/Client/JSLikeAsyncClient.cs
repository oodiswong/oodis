﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using TcpipServerService.Logger;
using TcpipServerService;

using System.Collections.Generic;
using System.Diagnostics;

namespace TcpipServerService.Client
{
    internal class JSLikeASyncClient : IClient
    {
        public static RunResults RunExecutable(string executablePath, string arguments, string workingDirectory)
        {
            RunResults runResults = new RunResults
            {
                Output = new StringBuilder(),
                Error = new StringBuilder(),
                RunException = null
            };

            try
            {
                if (File.Exists(executablePath))
                {
                    using (Process proc = new Process())
                    {
                        proc.StartInfo.FileName = executablePath;
                        proc.StartInfo.Arguments = '"' + arguments + '"';
                        proc.StartInfo.WorkingDirectory = workingDirectory;
                        proc.StartInfo.UseShellExecute = false;
                        proc.StartInfo.RedirectStandardOutput = true;
                        proc.StartInfo.RedirectStandardError = true;
                        proc.OutputDataReceived += (o, e) => runResults.Output.Append(e.Data).Append(Environment.NewLine);
                        proc.ErrorDataReceived += (o, e) => runResults.Error.Append(e.Data).Append(Environment.NewLine);

                        proc.Start();
                        proc.BeginOutputReadLine();
                        proc.BeginErrorReadLine();
                        proc.WaitForExit();
                        runResults.ExitCode = proc.ExitCode;
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid executable path.", "executablePath");
                }
            }
            catch (Exception e)
            {
                runResults.RunException = e;
            }

            return runResults;

        }

        public string Process(IPEndPoint localEndPoint, ILogger logger, string text, StreamReader file_ptr, string processname, string desktopid, string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no)
        {
            string result = string.Empty;
            ManualResetEvent allDone = new ManualResetEvent(false);

            this.Execute(localEndPoint, logger, text, processname, desktopid, ws_timeout, ws_invoke_cnt, ws_max_cnt, ws_desktop_seq_no, ws_task_seq_no, (Exception ex, string value) =>
            {
                result = value;
                allDone.Set();
            });

            allDone.WaitOne();
            return result;
        }

        public void End_Process()
        {
        }

        public void Execute(IPEndPoint localEndPoint, ILogger logger, string ws_text, string processname, string desktopid, string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no, Action<Exception, string> callback)
        {
            this.logger = logger;
            this.callback = callback;
            this.client = new TcpClient();
            this.state = null;
            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();
            NetworkStream netStream = null;

            try
            {
                IAsyncResult writeResult;
                //IAsyncResult lwriteResult;
                IAsyncResult readResult;
                this.client.Connect(localEndPoint);
                
                //Send process name to server
                netStream = this.client.GetStream();

                //Write process name + desktopid + timeout + invoke_cnt + max_cnt + desktop_seq_no to + task_seq_no server
                var writeBuffer = Encoding.UTF8.GetBytes(processname + "_" + desktopid + "_" + ws_timeout + "_" + ws_invoke_cnt.ToString() + "_" + ws_max_cnt.ToString() + "_" + ws_desktop_seq_no.ToString() + "_" + ws_task_seq_no.ToString() + "\n");

                netStream.Write(writeBuffer, 0, writeBuffer.Length);

                this.state = new AsyncClientState(this.client.GetStream(), ws_text + "\n");
                //writeResult = this.state.NetStream.BeginWrite(this.state.WriteBuffer, 0, this.state.WriteBuffer.Length, new AsyncCallback(this.writeCallback), this.state);
 
                string local_ip = this.client.Client.LocalEndPoint.ToString();
                string rmt_ip = this.client.Client.RemoteEndPoint.ToString();

                //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient connected to server [" + rmt_ip + "]");
                print_log("Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient connected to server [" + rmt_ip + "]");
                //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient connected to server [" + rmt_ip + "]");
                
                //string[] cmd_line_arg = ws_text.Split(' ');
                string[] cmd_line_arg = ws_text.Split(new char[] { ' ' }, 3);

                writeResult = this.state.NetStream.BeginWrite(this.state.WriteBuffer, 0, this.state.WriteBuffer.Length, null, null);
                this.state.NetStream.EndWrite(writeResult);

                //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient Client wrote [" + this.state.Input.Trim() + "] to [" + rmt_ip + "]");
                print_log("Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient Client wrote [" + this.state.Input.Trim() + "] to [" + rmt_ip + "]");
                //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient Client wrote [" + this.state.Input + "] to [" + rmt_ip + "]");

                String org_dir_file;
                int ws_cnt = 1;

                switch (cmd_line_arg[0])
                {
                    case "sleep":
                       //print_log(this.logger, "SleepFunc [" + cmd_line_arg[1] + "]");
                       print_log("SleepFunc [" + cmd_line_arg[1] + "]");
                       //Console.WriteLine("SleepFunc [" + cmd_line_arg[1] + "]");
                       string ws_rmt_info = client.Client.RemoteEndPoint.ToString();

                       int ws_sleep_sec = Int32.Parse(cmd_line_arg[1]);

                       Thread.Sleep(ws_sleep_sec);
                       this.executeCallback(null, string.Empty);
                       break;
                    case "whoami":
                       readResult = this.state.NetStream.BeginRead(this.state.ReadBuffer, 0, this.state.ReadBuffer.Length, new AsyncCallback(this.readCallback), this.state);
                       break;
                    case "runbatch":
                       readResult = this.state.NetStream.BeginRead(this.state.ReadBuffer, 0, this.state.ReadBuffer.Length, new AsyncCallback(this.readCallback), this.state);
                       break;
                    case "local_runbatch":

                       //batch or executable filename
                       string[] batch_exe = cmd_line_arg[2].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                       string[] the_rest = new string[batch_exe.Length - 1];
                       Console.WriteLine(" batch_exe " + string.Join(",", batch_exe));

                       //the rest
                       Array.Copy(batch_exe, 1, the_rest, 0, batch_exe.Length - 1);
                       Console.WriteLine(" the_rest " + string.Join(",", the_rest));

                       string lcl_run_result;
                       RunResults runResults = RunExecutable(batch_exe[0], the_rest[0], ".");
                       //RunResults runResults = RunExecutable(cmd_line_arg[2], cmd_line_arg[3] + " " + cmd_line_arg[4], ".");
                       if (runResults.RunException != null)
                       {
                           //Console.WriteLine(runResults.RunException);
                           lcl_run_result = runResults.RunException.ToString();
                       }
                       else
                       {
                           //Console.WriteLine("Output");
                           //Console.WriteLine("======");
                           //Console.WriteLine(runResults.Output);
                           //Console.WriteLine("Error");
                           //Console.WriteLine("=====");
                           //Console.WriteLine(runResults.Error);
                           lcl_run_result = runResults.Output.ToString();
                        }

                        //Console.WriteLine("lcl_run_result [" + lcl_run_result + "]");

                        this.state = new AsyncClientState(this.client.GetStream(), lcl_run_result + "\n");

                        //print_log(this.logger, " Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient local_runbatch wrote [" + this.state.Input.Trim() + "] to [" + rmt_ip + "]");
                        print_log("Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient local_runbatch wrote [" + this.state.Input.Trim() + "] to [" + rmt_ip + "]");
                        //this.logger.Cache(LoggerThreshold.Debug, "Local [" + local_ip + "T" + thread_id + "] JSLikeAsyncClient local_runbatch wrote [" + this.state.Input.Trim() + "] to [" + rmt_ip + "]");

                        writeResult = this.state.NetStream.BeginWrite(this.state.WriteBuffer, 0, this.state.WriteBuffer.Length, null, null);
                        this.state.NetStream.EndWrite(writeResult);
                        this.executeCallback(null, string.Empty);
                        break;
                    case "server_transfer":
                        //get file from server and write to client system

                        string[] st_cmd_line_arg = ws_text.Split(new char[] { ' ' }, 2);

                        //batch or executable filename
                        string[] source_file = st_cmd_line_arg[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                        Console.WriteLine("[JSLikeAsyncClient]server_transfer [" + string.Join(",", source_file) + "]");

                        NetworkStream st_netStream = client.GetStream();
                        //Syntax : server_transfer <server directory/file> <client remote directory/file>

                        org_dir_file = source_file[2];
                        //org_dir_file = cmd_line_arg[1];

                        //-----          
                        var ms = new MemoryStream();
                        byte[] data = new byte[1024];
                        int numBytesRead;
                        long total_sizes = 0;
                        string data_str;

                        ws_cnt = 1;
                        do
                        {
                            numBytesRead = st_netStream.Read(data, 0, data.Length);
                            data_str = Encoding.Default.GetString(data);

                            Console.Write("[" + ws_cnt.ToString() + "]");
                            ws_cnt = ws_cnt + 1;

                            if (data_str.Contains("THEEND"))
                            {
                                ms.Write(data, 0, numBytesRead - 7);
                                total_sizes = total_sizes + numBytesRead - 7;
                                break;
                            }
                            total_sizes = total_sizes + numBytesRead;
                            ms.Write(data, 0, numBytesRead);
                        } while (numBytesRead == data.Length);

                        //Write the file to local system
                        using (FileStream file = new FileStream(org_dir_file, FileMode.Create, System.IO.FileAccess.Write))
                        {
                            ms.WriteTo(file);
                            ms.Close();
                        }
                        this.executeCallback(null, string.Empty);
                        break;

                    case "client_transfer":
                        Thread.Sleep(50);

                        
                        string[] ct_cmd_line_arg = ws_text.Split(new char[] { ' ' }, 2);

                        //batch or executable filename
                        string[] ct_source_file = ct_cmd_line_arg[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                        Console.WriteLine("[ClasicAsyncClient]client_transfer [" + string.Join(",", ct_source_file) + "]");

                        //Read the local file and wrote to server
                        try
                        {
                            //org_dir_file = cmd_line_arg[1];
                            org_dir_file = ct_source_file[0];
                            NetworkStream ct_netStream = this.client.GetStream();

                            ws_cnt = 1;
                            using (BinaryReader b = new BinaryReader(
                            File.Open(org_dir_file, FileMode.Open)))
                            {
                               // 2.
                               // Position and length variables.
                               int pos = 0;
                               // 2A.
                               // Use BaseStream.
                               int length = (int)b.BaseStream.Length;
                               //logger.Cache(LoggerThreshold.Debug, "file length " + length.ToString());
                               while (pos < length)
                               {
                                  byte[] lcl_input = b.ReadBytes(20480);
                                  ct_netStream.Write(lcl_input, 0, lcl_input.Length);

                                  Console.Write("[" + ws_cnt.ToString() + "]");
                                  ws_cnt = ws_cnt + 1;
                                  // 4.
                                  // Advance our position variable.
                                  pos += lcl_input.Length;
                                  Thread.Sleep(50);
                               }

                               Thread.Sleep(50);
                               byte[] theend = Encoding.UTF8.GetBytes("THEEND\n"); ;
                               ct_netStream.Write(theend, 0, theend.Length);
                               ct_netStream.Flush();
                               Thread.Sleep(5540);

                               //print_log(logger, " Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                               print_log("Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                               //logger.Cache(LoggerThreshold.Debug, "Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient Client Total bytes [" + pos.ToString() + "] written to [" + rmt_ip + "]");
                            }
                        }
                        catch (Exception read_err)
                        {
                            //print_log(logger, " [JSLikeAsyncClient]Process client_transfer err " + read_err.ToString());
                            print_log("[JSLikeAsyncClient]Process client_transfer err " + read_err.ToString());
                            //logger.Cache(LoggerThreshold.Debug, "[JSLikeAsyncClient]Process client_transfer err " + read_err.ToString());
                        }
                        //this.client.Close();
                        this.executeCallback(null, string.Empty);
                        //this.client = new TcpClient();
                        //this.client.Connect(localEndPoint);
                        break;
                     default:
                        readResult = this.state.NetStream.BeginRead(this.state.ReadBuffer, 0, this.state.ReadBuffer.Length, new AsyncCallback(this.readCallback), this.state);
                        break;
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine("in try... " + ex.ToString());
                //print_log(this.logger, "in try... " + ex.ToString());
                //print_log(this.logger, ex.ToString());
                print_log("in try... " + ex.ToString());
                print_log(ex.ToString());
                //this.logger.Cache(LoggerThreshold.Error, ex.ToString());
                this.executeCallback(ex, string.Empty);
            }
        }

        private void final_executeCallback(Exception ex, string value)
        {
            //this.logger.Cache(LoggerThreshold.Debug, "[JSLikeasyncClient]final_executeCallback");
            //print_log(this.logger, " [JSLikeasyncClient]final_executeCallback");
            print_log("[JSLikeasyncClient]final_executeCallback");

            string lcl_local_ip = this.client.Client.LocalEndPoint.ToString();
            string lcl_rmt_ip = this.client.Client.RemoteEndPoint.ToString();

            //if ((this.state != null) && (this.state.NetStream != null))
            //{
                //Console.WriteLine("JSLikeAsyncClient]final_executeCallback netstream close.");
                //print_log(this.logger, " JSLikeAsyncClient]final_executeCallback netstream close.");
                print_log("JSLikeAsyncClient]final_executeCallback netstream close.");
                this.state.NetStream.Close();
            //}
            //if (this.client.Connected)
            //{
                //print_log(this.logger, " JSLikeAsyncClient]final_executeCallback client close.");
                print_log("JSLikeAsyncClient]final_executeCallback client close.");
                //Console.WriteLine("JSLikeAsyncClient]final_executeCallback client close.");
                this.client.Close();
            //}

            //print_log(this.logger, " Local [" + lcl_local_ip + "] JSLikeAsyncClient disconected from server " + lcl_rmt_ip + "]");
            print_log("Local [" + lcl_local_ip + "] JSLikeAsyncClient disconected from server " + lcl_rmt_ip + "]");
            //this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "] JSLikeAsyncClient disconected from server " + lcl_rmt_ip + "]");
            //this.logger.Flush();

            this.callback(ex, value);
        }

        private void executeCallback(Exception ex, string value)
        {            
            string lcl_local_ip = this.client.Client.LocalEndPoint.ToString();
            string lcl_rmt_ip = this.client.Client.RemoteEndPoint.ToString();
            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();

            if ((this.state != null) && (this.state.NetStream != null))
            {
                //Console.WriteLine("[JSLikeasyncClient]executeCallback netstream close");
                this.state.NetStream.Close();
            }
            if (this.client.Connected)
            {
                this.client.Close();
            }

            //print_log(this.logger, " Local [" + lcl_local_ip + "T" + thread_id + "] JSLikeAsyncClient disconected from server " + lcl_rmt_ip + "]");
            print_log(" Local [" + lcl_local_ip + "T" + thread_id + "] JSLikeAsyncClient disconected from server " + lcl_rmt_ip + "]");
            //this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "] JSLikeAsyncClient disconected from server "+ lcl_rmt_ip + "]");
            //this.logger.Flush();
            
            this.callback(ex, value);
        }

        private void readCallback(IAsyncResult asyncResult)
        {
            try
            {
                int bytesRead = this.state.NetStream.EndRead(asyncResult);
                this.state.AppendResponse(bytesRead);

                Thread thread = Thread.CurrentThread;
                string thread_id = thread.ManagedThreadId.ToString();

                if (this.state.NetStream.DataAvailable)
                    this.state.NetStream.BeginRead(this.state.ReadBuffer, 0, this.state.ReadBuffer.Length, new AsyncCallback(this.readCallback), this.state);
                else
                {
                    //print_log(this.logger, "Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient get [" + this.state.Response.ToString().Trim() + "] from [" + this.client.Client.RemoteEndPoint.ToString() + "]");   
                    print_log("Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient get [" + this.state.Response.ToString().Trim() + "] from [" + this.client.Client.RemoteEndPoint.ToString() + "]");   
                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + this.client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] JSLikeAsyncClient get ["+this.state.Response.ToString().Trim()+"] from ["+ this.client.Client.RemoteEndPoint.ToString() + "]");                   
                    this.executeCallback(null, this.state.Response.ToString());
                }
            }
            catch (Exception ex)
            {
                this.executeCallback(ex, string.Empty);
            }
        }

        //private static void print_log(ILogger logger, string ws_print_str)
        private static void print_log(string ws_print_str)
        {
            //var time = DateTime.Now;
            //string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");
            //logger.Cache(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);
            TcpipServerService.GlobalClass.WriteToFile(ws_print_str);

        }

        private ILogger logger;
        private Action<Exception, string> callback;
        private TcpClient client = new TcpClient();
        private AsyncClientState state = null;
    }
}