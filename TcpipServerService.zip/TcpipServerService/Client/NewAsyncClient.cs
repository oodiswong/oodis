﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TcpipServerService.Logger;

/*
namespace TcpipServerService.Client
{
    internal class NewASyncClient : IClient
    {
        public string Process(IPEndPoint localEndPoint, ILogger logger, string text, StreamReader file_ptr)
        {
            Console.WriteLine("[NewAsyncClient]Process");

            //Task<string> value = this.Execute(localEndPoint, logger, text);
            //value.Wait();

            //return value.Result;
            return "";
        }

        public async Task<string> Execute(IPEndPoint localEndPoint, ILogger logger, string text)
        {
            this.logger = logger;
            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();


            //Console.WriteLine("[NewAsyncClient][Execute] ["+ localEndPoint.Address.ToString()+"] port ["+ localEndPoint.Port.ToString()+"]"+text);

            TcpClient client = new TcpClient();

            bool bClosed= false;
            if (client.Client.Poll(0, SelectMode.SelectRead))
            {
                byte[] buff = new byte[1];
                if (client.Client.Receive(buff, SocketFlags.Peek) == 0)
                {
                    // Client disconnected
                    bClosed = true;
                }
            }
            if (bClosed)
            {
                Console.WriteLine("[NewAsyncClient][Execute]TCPClient CLOSED.");
            }
            string lcl_ip = localEndPoint.Address.ToString()+":"+ localEndPoint.Port.ToString();

            try
            {
                //Console.WriteLine("[NewAsyncClient][Execute]before await [" + text.ToString() + "]");
                await client.ConnectAsync(localEndPoint.Address, localEndPoint.Port);
                //Console.WriteLine("[NewAsyncClient][Execute]after await ["+text.ToString()+"]");

                //string rmt_ip = client.Client.RemoteEndPoint.ToString();
                //this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_ip + "T"+ thread_id + "] NewAsyncClient connected to server ["+ client.Client.RemoteEndPoint.ToString() + "]");

                using (var networkStream = client.GetStream())
                using (var writer = new StreamWriter(networkStream))
                using (var reader = new StreamReader(networkStream))
                {
                    writer.AutoFlush = true;
                    await writer.WriteAsync(text);
                    Console.WriteLine("Local [" + lcl_ip + "T" + thread_id +"] after WriteAsync [" + client.Client.RemoteEndPoint.ToString() + "]");
                    this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_ip + "T" + thread_id + "] NewAsyncClient wrote ["+text+"] to ["+ client.Client.RemoteEndPoint.ToString() + "]");

                    var bytesRead = 0;
                    var buffer = new char[1024];
                    var result = new StringBuilder();

                    while ((bytesRead = await reader.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        string s_buffer = new string(buffer);
                        //Console.WriteLine("before result [" + bytesRead.ToString() + "]["+ s_buffer +"]");
                        result.Append(buffer, 0, bytesRead);
                        //string s = new string(buffer);
                        //Console.WriteLine("within ReadAsync [" + s.Trim() + "]"+bytesRead.ToString());
                        break;
                    }
                    //Console.WriteLine("after ReadAsync ["+ result.ToString()+"]");

                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + client.Client.LocalEndPoint.ToString() + "] NewAsyncClient has read ["+result.ToString()+"] from " + client.Client.RemoteEndPoint.ToString() + "]");
                    //Console.WriteLine("Local [" + client.Client.LocalEndPoint.ToString() + "] NewAsyncClient get [" + result.ToString().Trim() + "] from ["+ client.Client.RemoteEndPoint.ToString()+"]");
                    this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_ip + "T" + thread_id + "] NewAsyncClient read [" + result.ToString().Trim() + "] from [" + client.Client.RemoteEndPoint.ToString() + "]");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                this.logger.Cache(LoggerThreshold.Error, ex.ToString());
            }
            finally
            {
                client.Close();
                this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_ip + "T" + thread_id + "] NewAsyncClient disconected from server "+ client.Client.RemoteEndPoint.ToString() + "]");
                this.logger.Flush();
            }
            this.logger.Flush();

            return string.Empty;
        }

        private ILogger logger;
    }
}
*/