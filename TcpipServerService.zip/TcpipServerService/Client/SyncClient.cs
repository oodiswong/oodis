﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using TcpipServerService.Logger;

using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace TcpipServerService.Client
{
    class RunResults
    {
        public int ExitCode;
        public Exception RunException;
        public StringBuilder Output;
        public StringBuilder Error;
    }

    internal class SyncClient : IClient
    {
        private TcpClient client;

        public static RunResults RunExecutable(string executablePath, string arguments, string workingDirectory)
        {
            RunResults runResults = new RunResults
            {
                Output = new StringBuilder(),
                Error = new StringBuilder(),
                RunException = null
            };

            try
            {
                if (File.Exists(executablePath))
                {
                    using (Process proc = new Process())
                    {
                        //Console.WriteLine("[syncClient]RunExecutable [" + arguments + "]");
                        TcpipServerService.GlobalClass.WriteToFile("[syncClient]RunExecutable [" + arguments + "]");

                        proc.StartInfo.FileName = executablePath;
                        proc.StartInfo.Arguments = '"'+arguments+'"';
                        proc.StartInfo.WorkingDirectory = workingDirectory;
                        proc.StartInfo.UseShellExecute = false;
                        proc.StartInfo.RedirectStandardOutput = true;
                        proc.StartInfo.RedirectStandardError = true;
                        proc.OutputDataReceived += (o, e) => runResults.Output.Append(e.Data).Append(Environment.NewLine);
                        proc.ErrorDataReceived += (o, e) => runResults.Error.Append(e.Data).Append(Environment.NewLine);

                        proc.Start();
                        proc.BeginOutputReadLine();
                        proc.BeginErrorReadLine();
                        proc.WaitForExit();
                        runResults.ExitCode = proc.ExitCode;
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid executable path.", "executablePath");
                }
            }
            catch (Exception e)
            {
                runResults.RunException = e;
            }

            return runResults;

        }

        public string Process(IPEndPoint localEndPoint, ILogger logger, string text, StreamReader file_ptr, string processname, string desktopid, string ws_timeout, Int64 ws_invoke_cnt, Int64 ws_max_cnt, int ws_desktop_seq_no, int ws_task_seq_no)
        {
            //Console.WriteLine("[SyncClient]process");

            //TcpClient client = new TcpClient();
            client = new TcpClient();
            NetworkStream netStream = null;
            var returnValue = string.Empty;
           
            //Read the first line of text
            string line = file_ptr.ReadLine();
            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();

            string command_main;
            Byte[] bytes = new byte[2560];

            string lcl_local_ip = "UNKNOWN";
            string lcl_rmt_ip = "UNKNOWN";
            
            try
            {
                client.Connect(localEndPoint);

                print_log(logger, "Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client connected to server [" + client.Client.RemoteEndPoint.ToString() + "]");

                lcl_local_ip = client.Client.LocalEndPoint.ToString();
                lcl_rmt_ip = client.Client.RemoteEndPoint.ToString();

                netStream = client.GetStream();

                //Write process name + desktopid + timeout + invoke_cnt + max_cnt + desktop_seq_no to + task_seq_no server
                var writeBuffer = Encoding.UTF8.GetBytes(processname + "_" + desktopid + "_" + ws_timeout + "_" + ws_invoke_cnt.ToString() + "_" + ws_max_cnt.ToString() + "_" + ws_desktop_seq_no.ToString() + "_" + ws_task_seq_no.ToString() + "\n");
                netStream.Write(writeBuffer, 0, writeBuffer.Length);

                //temnporary add in
                Thread.Sleep(5000);
                
                print_log(logger, "Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client write identity [" + System.Text.Encoding.UTF8.GetString(writeBuffer, 0, writeBuffer.Length).Trim() + "] to server [" + client.Client.RemoteEndPoint.ToString() + "]");

                //Continue to read until you reach end of file
                while (line != null || file_ptr.Peek() != -1)
                {
                    string[] argumnts = new string[4];

                    writeBuffer = Encoding.UTF8.GetBytes(line+"\n");
                    netStream.Write(writeBuffer, 0, writeBuffer.Length);

                    print_log(logger, "Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote [" + line + "] to [" + client.Client.RemoteEndPoint.ToString() + "]");
                    //Console.WriteLine(" Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote [" + line + "] to [" + client.Client.RemoteEndPoint.ToString() + "]");
     
                    //string[] tmp1 = line.Split(' ');
                    string[] tmp1 = line.Split(new char[] { ' ' }, 3);
                    
                    command_main = tmp1[0].Trim();
                    if (command_main == "client_transfer" || command_main == "server_transfer")
                    {
                        tmp1 = line.Split(new char[] { ' ' }, 2);

                        //batch or executable filename
                        string[] source_file = tmp1[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);
                        //print_log(logger, " source_file [" + string.Join(",", source_file) + "]");
                        //print_log(logger, "["+source_file[0] + "]");
                        //print_log(logger, "[" + source_file[2] + "]");
                        argumnts[0] = source_file[0];
                        argumnts[1] = source_file[2];
                    }
                    else if (command_main == "local_runbatch")
                    {
                        //batch or executable filename
                        string[] batch_exe = tmp1[2].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                        string[] the_rest = new string[batch_exe.Length - 1];
                        //Console.WriteLine(" batch_exe " + string.Join(",", batch_exe));

                        //the rest
                        Array.Copy(batch_exe, 1, the_rest, 0, batch_exe.Length - 1);
                        print_log(logger, "the_rest [" + string.Join(",", the_rest)+"]");


                        //Console.WriteLine(command_main + " argumnts " + string.Join(" ", argumnts));
                        //Array.Copy(tmp1, 1, argumnts, 0, tmp1.Length - 1);
                        argumnts[0] = tmp1[1];
                        argumnts[1] = batch_exe[0];
                        //Change to 1 due to its value is ,para 1,

                        Console.WriteLine("batch_exe length " + batch_exe.Length.ToString());

                        if (batch_exe.Length > 2)
                        {
                            argumnts[2] = the_rest[1];
                        }
                        else
                        {
                            argumnts[2] = "";
                        }                      
                    }
                    else
                    {
                        argumnts = new string[tmp1.Length - 1];
                        Array.Copy(tmp1, 1, argumnts, 0, tmp1.Length - 1);
                    }
                    /*
                    command_main = tmp1[0].Trim();
                    string[] argumnts = new string[tmp1.Length - 1];
                    Array.Copy(tmp1, 1, argumnts, 0, tmp1.Length - 1);
                    */
                    string[] ws_rmt_info = new string[] { client.Client.RemoteEndPoint.ToString() };

                    if (lCommands.ContainsKey(command_main))
                    {
                        Action<string[], NetworkStream, TcpClient, ILogger, string> function_to_execute = null;
                        string[] pass_args = argumnts;

                        //**********
                        //This needs to be waited 20 millseconds and wrote null character in order
                        //for server to be ready
                        Thread.Sleep(20);
                        byte[] v = Encoding.ASCII.GetBytes(""); ;
                        //netstream.Write(v, 0, v.Length);
                        netStream.Write(v, 0, v.Length);
                        //**********

                        lCommands.TryGetValue(command_main, out function_to_execute);

                        function_to_execute(pass_args, netStream, client, logger, thread_id);
                    }
                    else
                    {
                        //Unrecognized command

                        var readBuffer = new byte[256];
                        var bytesRead = netStream.Read(readBuffer, 0, readBuffer.Length);
                        //Console.WriteLine("bytesread " + bytesRead.ToString());
                        var readbuffer_temp = new byte[bytesRead];
                        Array.Copy(readBuffer, readbuffer_temp, bytesRead);
                        string read_line = System.Text.Encoding.Default.GetString(readbuffer_temp);
                        read_line = read_line.Trim();

                        print_log(logger, "unrecognized Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get [" + read_line + "] from [" + client.Client.RemoteEndPoint.ToString() + "]");
                        //logger.Cache(LoggerThreshold.Debug, "Local [" + client.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get [" + read_line + "] from [" + client.Client.RemoteEndPoint.ToString() + "]");
                    }

                    //if (command_main == "client_transfer" || command_main == "server_transfer")
                    /*if (command_main == "server_transfer")
                    {
                        print_log(logger, "reopen tcpclient");
                        //Reopen the tcpclient
                        client = new TcpClient();
                        client.Connect(localEndPoint);
                        netStream = client.GetStream();

                        //Write process name to server
                        var re_writeBuffer = Encoding.UTF8.GetBytes(processname + "\n");
                        netStream.Write(re_writeBuffer, 0, re_writeBuffer.Length);
                    }
                    */

                    //Read the next line
                    line = file_ptr.ReadLine();
                }
                file_ptr.Close();
            }
            catch (Exception ex)
            {
                string err_msg = ex.ToString();

                if (!err_msg.Contains("aborted by the software in your host machine"))
                {
                    print_log(logger, "Process Catch [" + ex.ToString() + "]");
                    //logger.Cache(LoggerThreshold.Error, "Process Catch [" + ex.ToString() + "]");
                }
            }

            if (netStream != null) netStream.Close();
            if (client.Connected) client.Close();
            print_log(logger, "Local [" + lcl_local_ip + "T" + thread_id + "] SyncClient Client disconected from server [" + lcl_rmt_ip + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local ["+ lcl_local_ip + "T"+thread_id+"] SyncClient Client disconected from server [" + lcl_rmt_ip + "]");

            //logger.Flush();

            //Console.WriteLine("before return [" + returnValue + "]");
            return "";
            //return returnValue;
        }

        public void End_Process()
        {
            Console.WriteLine("[Syncclient]End_Process");
            client.Close();
        }

        private static Dictionary<string, Action<string[], NetworkStream, TcpClient, ILogger, string>> lCommands =
        new Dictionary<string, Action<string[], NetworkStream, TcpClient, ILogger, string>>()
        {
            //{ "help", HelpFunc },
            //{ "cp" , CopyFunc },
            //{ "ls" , LsFunc }
            { "THEEND" , TheendFunc },
            { "whoami", WhoamiFunc },
            { "runbatch" , RunBatchFunc },
            { "local_runbatch" , LocalRunBatchFunc },
            { "sleep" , SleepFunc },
            //{ "thread", ThreadFunc },
            { "server_transfer", s_transferFunc },
            { "client_transfer", c_transferFunc }
        };
       
        private static void TheendFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();
            string ws_local_info = tcpclient.Client.LocalEndPoint.ToString();
            //print_log(logger, "TheendFunc");
            Console.WriteLine("TheendFunc");

            //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + reader_string + "]");
            print_log(logger, "Local [" + ws_local_info + "T" + thread_id + "][SyncServer]TheendFunc from [" + ws_rmt_info + "]");
            //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc from [" + ws_rmt_info + "]");

        }

        private static void print_log(ILogger logger, string ws_print_str)
        {
            //var time = DateTime.Now;
            //string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");
            //logger.Cache(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);
            TcpipServerService.GlobalClass.WriteToFile(ws_print_str);

        }

        private static void s_transferFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            Byte[] bytes = new byte[2560];
            string ws_local_info = tcpclient.Client.LocalEndPoint.ToString();
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            //Syntax : server_transfer <server directory/file> <client remote directory/file>

            //string line;
            String org_dir_file = obj[0];

            //-----
            //client read file from server
            var ms = new MemoryStream();
            byte[] data = new byte[20480];
            int numBytesRead;
            long total_sizes = 0;
            string data_str;
            //print_log(logger, " Read from server ");
            int ws_cnt = 1;
            do
            {
                numBytesRead = obj1.Read(data, 0, data.Length);
                data_str = Encoding.Default.GetString(data);
                Console.Write("[" + ws_cnt.ToString() + "]");
                ws_cnt = ws_cnt + 1;
                if (data_str.Contains("THEEND"))
                {
                    ms.Write(data, 0, numBytesRead - 7);
                    total_sizes = total_sizes + numBytesRead - 7;
                    break;
                }
                total_sizes = total_sizes + numBytesRead;
                ms.Write(data, 0, numBytesRead);

            } while (numBytesRead == data.Length);

            //logger.Cache(LoggerThreshold.Debug, "numBytesRead " + numBytesRead.ToString());

            //Write the file to local system
            using (FileStream file = new FileStream(obj[1], FileMode.Create, System.IO.FileAccess.Write))
            {
                ms.WriteTo(file);
                ms.Close();
            }

            logger.Cache(LoggerThreshold.Debug, "Local [" + ws_local_info + "T" + thread_id + "][SyncClient]s_transferFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + total_sizes.ToString() + "]");

            //Read the THEEND statement
            numBytesRead = obj1.Read(data, 0, data.Length);
            data_str = Encoding.Default.GetString(data);
            logger.Cache(LoggerThreshold.Debug, "Local [" + ws_local_info + "T" + thread_id + "][SyncClient]s_transferFunc reread from [" + ws_rmt_info + "] Statement [" + data_str.Trim().Split('\n')[0] + "]");

            //-----
        }

        private static void c_transferFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            Byte[] bytes = new byte[2560];
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            //print_log(logger, "c_transferFunc function." + obj[0] + " " + obj[1]);
            Console.WriteLine("c_transferFunc function [" + obj[0] + "][" + obj[1]+"]");

            //Syntax : client_transfer <local directory/file> <server remote directory/file>

            //string line;
            String org_dir_file = obj[0];

            //print_log(logger, "Transfer [" + org_dir_file + "]");
            //Console.WriteLine("Transfer [" + org_dir_file + "]");

            try
            {
                using (BinaryReader b = new BinaryReader(
                File.Open(org_dir_file, FileMode.Open)))
                {
                    // 2.
                    // Position and length variables.
                    int pos = 0;
                    int ws_cnt = 1;
                    // 2A.
                    // Use BaseStream.
                    int length = (int)b.BaseStream.Length;
                    //print_log(logger, "file length " + length.ToString());
                    //Console.WriteLine("file length " + length.ToString());
                    while (pos < length)
                    {
                        byte[] v = b.ReadBytes(20480);
                        //logger.Cache(LoggerThreshold.Debug, "read from file [" + Encoding.UTF8.GetString(v) + "]");
                        //netstream.Write(v, 0, v.Length);
                        obj1.Write(v, 0, v.Length);
                        Console.Write("[" + ws_cnt.ToString() + "]");
                        ws_cnt = ws_cnt + 1;
                        //print_log(logger, "write to port [" + v.Length + "]");
                        // 4.
                        // Advance our position variable.
                        pos += v.Length;
                        Thread.Sleep(50);
                    }
                    Thread.Sleep(50);
                    byte[] theend = Encoding.UTF8.GetBytes("THEEND\n"); ;
                    obj1.Write(theend, 0, theend.Length);
                    obj1.Flush();
                    Thread.Sleep(5540);

                    //logger.Cache(LoggerThreshold.Debug, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] [SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                    print_log(logger, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] [SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                    //Console.WriteLine(" Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] [SyncClient Client Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                }
            }
            catch (Exception read_err)
            {
                //logger.Cache(LoggerThreshold.Debug, "transferFunc err "+read_err.ToString());
                print_log(logger, "transferFunc err " + read_err.ToString());
            }

            //Console.WriteLine("[SyncClient]transferFunc before close file");
            //netstream.Close();
            //obj1.Close();
            //temporary mask off
            //print_log(logger, "Client close socket");

            //tcpclient.Close();
            //tcpclient = new TcpClient(IPA, PortN);
            //netstream = client.GetStream();
        }

        private static void SleepFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            //print_log(logger, " SleepFunc");
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            int ws_sleep_sec = Int32.Parse(obj[0]);

            print_log(logger, "SleepFunc " + ws_sleep_sec.ToString());
            //logger.Cache(LoggerThreshold.Debug, "SleepFunc " + ws_sleep_sec.ToString());
            Thread.Sleep(ws_sleep_sec);
        }

        private static void WhoamiFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            //print_log(logger, "WhoamiFunc");
            //Console.WriteLine("[SyncClient]WhoamiFunc");
            TcpipServerService.GlobalClass.WriteToFile("[SyncClient]WhoamiFunc");
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            var result = new StringBuilder();
            var readBuffer = new byte[256];
            var totalBytes = 0;
            do
            {
                var bytesRead = obj1.Read(readBuffer, 0, readBuffer.Length);
                result.Append(Encoding.UTF8.GetString(readBuffer, 0, bytesRead));
                totalBytes += bytesRead;
            }
            while (tcpclient.Available > 0);

            //print_log(logger, " Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //Console.WriteLine("Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T"+thread_id+ "] SyncClient Client get [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");

        }

        private static void RunBatchFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            //Console.WriteLine("RunBatchFunc ");

            var result = new StringBuilder();
            var readBuffer = new byte[256];
            var totalBytes = 0;
            do
            {
                var bytesRead = obj1.Read(readBuffer, 0, readBuffer.Length);
                result.Append(Encoding.UTF8.GetString(readBuffer, 0, bytesRead));
                totalBytes += bytesRead;
            }
            while (tcpclient.Available > 0);

            TcpipServerService.GlobalClass.WriteToFile("Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get  [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //print_log(logger, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client get  [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T"+thread_id+ "] SyncClient Client get  [" + result.ToString().Trim() + "] from [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");


        }

        private static void LocalRunBatchFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, ILogger logger, string thread_id)
        {
            //print_log(logger, "[SyncClient]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "]");
            //Console.WriteLine("[SyncClient]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "]");
            TcpipServerService.GlobalClass.WriteToFile("[SyncClient]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "]");

            string lcl_run_result;
            
            RunResults runResults = RunExecutable(obj[1], obj[2] + " " + obj[3], ".");
            if (runResults.RunException != null)
            {
                //Console.WriteLine(runResults.RunException);
                lcl_run_result = runResults.RunException.ToString();
            }
            else
            {
                //Console.WriteLine("Output");
                //Console.WriteLine("======");
                //Console.WriteLine(runResults.Output);
                //Console.WriteLine("Error");
                //Console.WriteLine("=====");
                //Console.WriteLine(runResults.Error);
                lcl_run_result = runResults.Output.ToString();
            }

            var writeBuffer = Encoding.UTF8.GetBytes(lcl_run_result + "\n");
            obj1.Write(writeBuffer, 0, writeBuffer.Length);
            obj1.Flush();
            //Console.WriteLine("Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote  [" + lcl_run_result.ToString().Trim() + "] to [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote  [" + lcl_run_result.ToString().Trim() + "] to [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //Need a sleep, if not, it will send the next command to server in the buffer
            Thread.Sleep(1000);
            //logger.Cache(LoggerThreshold.Debug, "Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote  [" + lcl_run_result.ToString().Trim() + "] to [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
            //print_log(logger, " Local [" + tcpclient.Client.LocalEndPoint.ToString() + "T" + thread_id + "] SyncClient Client wrote  [" + lcl_run_result.ToString().Trim() + "] to [" + tcpclient.Client.RemoteEndPoint.ToString() + "]");
        }
    }

}