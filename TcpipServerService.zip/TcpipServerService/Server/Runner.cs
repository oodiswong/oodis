﻿using System;
using System.Net;
using System.Net.Sockets;
using TcpipServerService.Dispatcher;
using TcpipServerService.Logger;
using TcpipServerService.WorkLoad;
using System.Threading;

using System.Data.SqlClient;

using System.Collections.Generic;
using System.IO;
using System.ServiceProcess;
using System.Text;

namespace TcpipServerService.Server
{
    internal class Runner
    {
        public static StreamWriter sw;

        public int Run(Options options, SqlConnection connection, string ws_server_log_file, string ws_client_log_file)
        {
            //Console.WriteLine("[Server Runner]run");
            this.options = options;
            this.parseBaseElements(ws_server_log_file, ws_client_log_file);

            runSyncServer(options, connection);

            return 0;
        }

        private static Options parseOptions(string[] args)
        {
            string invokedVerb = null;
            object invokedVerbInstance = null;

            var options = new Options();
            if (!CommandLine.Parser.Default.ParseArgumentsStrict(args, options,
              (verb, subOptions) =>
              {
                  invokedVerb = verb;
                  invokedVerbInstance = subOptions;
              }))
            {
                Environment.Exit(CommandLine.Parser.DefaultExitCodeFail);
            }

            if (string.Compare(invokedVerb, "server", true) == 0)
            {
                options.Mode = Mode.Server;
                options.ServerVerb = invokedVerbInstance as ServerSubOptions;
            }
            else
            {
                options.Mode = Mode.Client;
                options.ClientVerb = invokedVerbInstance as ClientSubOptions;
            }

            return options;
        }

        //private void runSyncServer(Options options)
        private void runSyncServer(Options options, SqlConnection connection)
        {
            //Console.WriteLine("[Server Runner]runSyncServer [" + options.ServerVerb.ProcessName + "]connection["+connection.ToString()+"]");
            //logger.Log(LoggerThreshold.Debug, "[Server Runner]runSyncServer [" + options.ServerVerb.ProcessName + "]connection[" + connection.ToString() + "]");
            TcpipServerService.GlobalClass.WriteToFile("[Server Runner]runSyncServer [" + options.ServerVerb.ProcessName + "]");

            TcpListener listener = new TcpListener(IPAddress.Any, options.ServerVerb.Port);
            listener.Start();

            this.dispatcher.Dispatch(listener, this.logger, this.workload.Workload, options.ServerVerb.ProcessName, connection);
        }

        private void parseBaseElements(string ws_server_log_file, string ws_client_log_file)
        {
            ServerSubOptions srvOptions = this.options.ServerVerb;

            switch (srvOptions.Dispatcher)
            {
                case DispatcherType.Thread:
                    this.dispatcher = new ThreadDispatcher();
                    break;

                case DispatcherType.Pool:
                    this.dispatcher = new PoolDispatcher(srvOptions.NumOfConcurentProceses);
                    break;

                case DispatcherType.Dynamic:
                    this.dispatcher = new DynamicDispatcher(srvOptions.NumOfConcurentProceses);
                    break;
            }

            switch (srvOptions.Workload)
            {
                case WorkloadType.Echo:
                    this.workload = new Echo(srvOptions.MinWorkloadTime, srvOptions.MaxWorkloadTime, srvOptions.RealWork);
                    break;

                case WorkloadType.Time:
                    this.workload = new Time(srvOptions.MinWorkloadTime, srvOptions.MaxWorkloadTime, srvOptions.RealWork);
                    break;
            }

            //temporary mask off
            //this.logger = (ILogger)(new FileLogger(ws_server_log_file, ws_server_log_file, ws_client_log_file, 1));
            //this.logger = (string.IsNullOrEmpty(srvOptions.LogFileName)) ?
            //  (ILogger)(new ConsoleLogger(ws_server_log_file, ws_client_log_file, 1)) :
            //  (ILogger)(new FileLogger(srvOptions.LogFileName, ws_server_log_file, ws_client_log_file, 1));
            ////this.logger.LogThreshold = srvOptions.LoggerThreshold;

            /*
            if (srvOptions.RealWork)
                this.logger.Log(LoggerThreshold.Debug, "real work");
            else
                this.logger.Log(LoggerThreshold.Debug, "NOT real work");
            */
            if (srvOptions.RealWork)
                TcpipServerService.GlobalClass.WriteToFile("real work");
            else
                TcpipServerService.GlobalClass.WriteToFile("NOT real work");
        }

        private Options options;
        private IDispatcher dispatcher;
        private IWorkload workload;
        private ILogger logger;
    }
}