﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using TcpipServerService.Logger;

using System.Diagnostics;
using System.Threading;
using System.Text.RegularExpressions;

using System.Data.SqlClient;

namespace TcpipServerService.Server
{
    class RunResults
    {
        public int ExitCode;
        public Exception RunException;
        public StringBuilder Output;
        public StringBuilder Error;
    }

    internal class SyncServer
    {
        //public SyncServer(TcpClient tcpClient, ILogger logger, Func<string, string> workload)
        public SyncServer(TcpClient tcpClient, ILogger logger, Func<string, string> workload, SqlConnection connection, string processname)
        {
            //Console.WriteLine("[SyncServer]SyncServer");
            this.tcpClient = tcpClient;
            this.logger = logger;
            this.workload = workload;
            this.connection = connection;
            this.processname = processname;
            //this.networkstream = networkstream;
        }

        public void Run()
        {
            string command_main;
            Byte[] bytes = new byte[2560];
            StreamReader reader;           

            Thread thread = Thread.CurrentThread;
            string thread_id = thread.ManagedThreadId.ToString();
            string lcl_local_ip = this.tcpClient.Client.LocalEndPoint.ToString();
            int mainThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId;

            TcpipServerService.GlobalClass.WriteToFile("[SyncServer]Run mainthreadid [" + mainThreadId.ToString() + "][" + this.tcpClient.Available.ToString() + "]");
            //Console.WriteLine("[SyncServer]Run mainthreadid [" + mainThreadId.ToString() + "][" + this.tcpClient.Available.ToString()+"]");
            
            try
            {
                var networkStream = this.tcpClient.GetStream();
                //using (var networkStream = this.tcpClient.GetStream())
                //{
                

                    try
                    {
                        while (true)
                        {
                            var buffer = new byte[256];
                            var sb = new StringBuilder();

                            string reader_string="reader";
                            reader = new StreamReader(networkStream);
                                
                            reader_string = reader.ReadLine();
                            //Console.WriteLine("[SynServer]Run() reader_string [" + reader_string + "]");
                            TcpipServerService.GlobalClass.WriteToFile("[SynServer]Run() reader_string [" + reader_string + "]");
    
                            //reader_string = reader.ReadLine();
                            //Console.WriteLine("[SynServer]Run() reader_string1 [" + reader_string + "]");
                                
                            string rmt_endpoint = this.tcpClient.Client.RemoteEndPoint.ToString();
                                
                            //string input = sb.ToString();
                            string input = reader_string;
                                
                            string[] tmp1;
                            string[] argumnts = new string[4];

                            if (reader_string == "" || reader_string == null)
                            {
                                //this.logger.Cache(LoggerThreshold.Debug, "exit loop from connection...");
                                //print_log(this.logger, " exit loop from connection...");
                                TcpipServerService.GlobalClass.WriteToFile("exit loop from connection...");
                                tmp1 = new string[0];
                                this.tcpClient.Client.Close();
                                //Thread.CurrentThread.Abort();
                             
                                break;
                            }
                            else
                            {
                                tmp1 = reader_string.Split(new char[] { ' ' }, 3);

                                command_main = tmp1[0].Trim();

                                TcpipServerService.GlobalClass.WriteToFile("[SyncServer]Run command_main [" + command_main + "]");
                                //Console.WriteLine("[SyncServer]Run command_main [" + command_main + "]");
                                if (command_main == "runbatch" || command_main == "local_runbatch")
                                {
                                    //batch or executable filename
                                    string[] batch_exe = tmp1[2].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);

                                    string[] the_rest = new string[batch_exe.Length - 1];
                                    //Console.WriteLine(" batch_exe " + string.Join(",", batch_exe));

                                    //the rest
                                    Array.Copy(batch_exe, 1, the_rest, 0, batch_exe.Length - 1);
                                    //print_log(this.logger, " the_rest " + string.Join(",", the_rest));
                                    TcpipServerService.GlobalClass.WriteToFile(" the_rest " + string.Join(",", the_rest));
                                   
                                    //Console.WriteLine(command_main + " argumnts " + string.Join(" ", argumnts));
                                    //Array.Copy(tmp1, 1, argumnts, 0, tmp1.Length - 1);
                                    argumnts[0] = tmp1[1];
                                    argumnts[1] = batch_exe[0];
                                    argumnts[2] = the_rest[0];
                                }
                                else if (command_main == "client_transfer" || command_main == "server_transfer")
                                {
                                    tmp1 = reader_string.Split(new char[] { ' ' }, 2);

                                    //batch or executable filename
                                    string[] source_file = tmp1[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);
                                    //print_log(this.logger, " source_file [" + string.Join(",", source_file) + "]");
                                    TcpipServerService.GlobalClass.WriteToFile("source_file [" + string.Join(",", source_file) + "]");
                                    argumnts[0] = source_file[0];
                                    argumnts[1] = source_file[2];
                                }

                                //argumnts[3] = the_rest[2];
                                //print_log(this.logger, " argumnts [" + string.Join(",", argumnts) + "]");
                                string ws_rmt_info = this.tcpClient.Client.RemoteEndPoint.ToString() + "T" + thread_id ;
                                //Console.WriteLine("arg len " + ws_rmt_info.Length.ToString() + " " + string.Join(" ", argumnts));

                                TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run get [" + input + "] from [" + rmt_endpoint + "]");
                                //Console.WriteLine("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run get [" + input + "] from [" + rmt_endpoint + "]");
                                //print_log(this.logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run get [" + input + "] from [" + rmt_endpoint + "]");
 
                                //string output = this.workload(input).Trim();
                                string output = input.Trim();

                                if (output == "" | output == null)
                                {
                                   //this.logger.Cache(LoggerThreshold.Debug, "break the loop");
                                   //print_log(this.logger, " break the loop");
                                   TcpipServerService.GlobalClass.WriteToFile("break the loop");
                                   break;
                                }

                                if (lCommands.ContainsKey(command_main))
                                {
                                   Action<string[], NetworkStream, TcpClient, string, string, ILogger, SqlConnection, string,  StreamReader> function_to_execute = null;
                                   string[] pass_args = argumnts;

                                   lCommands.TryGetValue(command_main, out function_to_execute);
                                   //Console.WriteLine("[SynServer]Run [" + string.Join("| ", pass_args));
                                   TcpipServerService.GlobalClass.WriteToFile("[SynServer]Run [" + string.Join("| ", pass_args));
                                   function_to_execute(pass_args, networkStream, this.tcpClient, thread_id, lcl_local_ip, this.logger, this.connection, this.processname, reader);
                                }
                                else
                                {
                                    //Unrecognized command
                                    byte[] sendBuffer = Encoding.UTF8.GetBytes("["+command_main+"] Unrecognized Command");
                                    TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run send [Unrecognized Command] to [" + rmt_endpoint + "]");
                                    //this.logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run send [Unrecognized Command] to [" + rmt_endpoint + "]");
                                    //Console.WriteLine("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]Run send [Unrecognized Command] to [" + rmt_endpoint + "]");
                                    networkStream.Write(sendBuffer, 0, (int)sendBuffer.Length);
                                }
                            }

                            /*
                             if ((int)this.logger.LogThreshold <= (int)LoggerThreshold.Minimal)
                               this.logger.Cache(LoggerThreshold.Minimal, ".");   
                            */
                        }
                    }
                    catch (Exception cnt_err)
                    {
                        String cnt_err_str = cnt_err.ToString();
                        if (cnt_err_str.Contains("System.ArgumentException: Stream was not readable.") ||
                            cnt_err_str.Contains("An existing connection was forcibly closed by the remote host") ||
                            cnt_err_str.Contains("An established connection was aborted by the software"))
                        {
                            //Catch error here System.ArgumentException: Stream was not readable.
                            //Don't classify this is an error
                        }
                        else
                        {
                            //print_log(this.logger, " Catch error here " + cnt_err_str);
                            TcpipServerService.GlobalClass.WriteToFile("Catch error here " + cnt_err_str);
                            //this.logger.Cache(LoggerThreshold.Debug, "Catch error here " + cnt_err.ToString());
                            this.tcpClient.Close();
                        }
                        //this.logger.Flush();
                    }
                //}
            }
            catch (SocketException se)
            {
                //print_log(this.logger, se.ErrorCode + ": " + se.Message);
                TcpipServerService.GlobalClass.WriteToFile(se.ErrorCode + ": " + se.Message);
                //this.logger.Cache(LoggerThreshold.Error, se.ErrorCode + ": " + se.Message);
            }
            catch (IOException io)
            {
                //print_log(this.logger, io.Data + ": " + io.Message);
                TcpipServerService.GlobalClass.WriteToFile(io.Data + ": " + io.Message);
                //this.logger.Cache(LoggerThreshold.Error, io.Data + ": " + io.Message);
            }

            //print_log(this.logger, " close socket");
            //Console.WriteLine("[SyncServer]Run() close socket");
            TcpipServerService.GlobalClass.WriteToFile("[SyncServer]Run() close socket");
            
            //this.tcpClient.Client.Close();
            //temporary mask off
            this.tcpClient.Close();
            //this.logger.Flush();
        }

        public static RunResults RunExecutable(string executablePath, string arguments, string workingDirectory)
        {
            RunResults runResults = new RunResults
            {
                Output = new StringBuilder(),
                Error = new StringBuilder(),
                RunException = null,
                ExitCode = 0
            };

            try
            {
                if (File.Exists(executablePath))
                {
                    using (Process proc = new Process())
                    {
                        proc.StartInfo.FileName = executablePath;
                        proc.StartInfo.Arguments = arguments;
                        proc.StartInfo.WorkingDirectory = workingDirectory;
                        proc.StartInfo.UseShellExecute = false;
                        proc.StartInfo.RedirectStandardOutput = true;
                        proc.StartInfo.RedirectStandardError = true;
                        proc.OutputDataReceived += (o, e) => runResults.Output.Append(e.Data).Append(Environment.NewLine);
                        proc.ErrorDataReceived += (o, e) => runResults.Error.Append(e.Data).Append(Environment.NewLine);

                        proc.Start();
                        proc.BeginOutputReadLine();
                        proc.BeginErrorReadLine();
                        proc.WaitForExit();
                        runResults.ExitCode = proc.ExitCode;
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid executable path.", "executablePath");
                }
            }
            catch (Exception e)
            {
                runResults.RunException = e;
            }

            return runResults;

        }

        //private static Dictionary<string, Action<string[]>> lCommands =
        //new Dictionary<string, Action<string[]>>()
        private static Dictionary<string, Action<string[], NetworkStream, TcpClient, string, string, ILogger, SqlConnection, string, StreamReader>> lCommands =
        new Dictionary<string, Action<string[], NetworkStream, TcpClient, string, string, ILogger, SqlConnection, string, StreamReader>>()
                {
                //{ "help", HelpFunc },
                //{ "cp" , CopyFunc },
                //{ "ls" , LsFunc }
                { "THEEND" , TheendFunc },
                { "whoami", WhoamiFunc },
                { "runbatch" , RunBatchFunc },                
                { "local_runbatch" , LocalRunBatchFunc }, 
                { "sleep" , SleepFunc },
                { "server_transfer", s_transferFunc },
                { "client_transfer", c_transferFunc }
        };

        private static void TheendFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();
            string ws_local_info = tcpclient.Client.LocalEndPoint.ToString();


            //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + reader_string + "]");
            //print_log(logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc from [" + ws_rmt_info + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc from [" + ws_rmt_info + "]");
            //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]TheendFunc from [" + ws_rmt_info + "]");
                  
        }

        private static void s_transferFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();
            string ws_local_info = tcpclient.Client.LocalEndPoint.ToString();

            //-------
            try
            {
                String org_dir_file = obj[0];
                using (BinaryReader b = new BinaryReader(
                File.Open(org_dir_file, FileMode.Open)))
                {
                    // 2.
                    // Position and length variables.
                    int pos = 0;
                    // 2A.
                    // Read the local file and send to remote system
                    int length = (int)b.BaseStream.Length;
                    while (pos < length)
                    {
                        byte[] v = b.ReadBytes(20480);
                        obj1.Write(v, 0, v.Length);
                        //print_log(logger, "write to port [" + v.Length + "]");
                        pos += v.Length;
                        Thread.Sleep(50);
                    }
                    //tcpclient.Close();
                    Thread.Sleep(50);
                    byte[] theend = Encoding.UTF8.GetBytes("THEEND\n"); ;
                    obj1.Write(theend, 0, theend.Length);
                    obj1.Flush();
                    Thread.Sleep(5540);

                    TcpipServerService.GlobalClass.WriteToFile("Local [" + ws_local_info + "T" + thread_id + "][SyncServer]s_transferFunc Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                    //print_log(logger, " Local [" + ws_local_info + "T" + thread_id + "][SyncServer]s_transferFunc Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                    //logger.Cache(LoggerThreshold.Debug, "Local [" + ws_local_info + "T" + thread_id + "][SyncServer]s_transferFunc Total bytes [" + pos.ToString() + "] written to [" + ws_rmt_info + "]");
                }
            }
            catch (Exception read_err)
            {
                //print_log(logger, " transferFunc err " + read_err.ToString());
                TcpipServerService.GlobalClass.WriteToFile("transferFunc err " + read_err.ToString());
                //logger.Cache(LoggerThreshold.Debug, "transferFunc err " + read_err.ToString());
            }

            //tcpclient.Close();
            //-------
        }

        //TRANSFER function
        private static void c_transferFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            //logger.Cache(LoggerThreshold.Debug, "server_transferfile function. [" + obj[0] + "]");
            //Console.WriteLine("[SyncServer]c_transferFunc ");
            TcpipServerService.GlobalClass.WriteToFile("[SyncServer]c_transferFunc ");
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            //client transfer file to server
            var ms = new MemoryStream();
            byte[] data = new byte[20480];
            int numBytesRead;
            long total_sizes=0;
            string data_str;
            do
            {
                numBytesRead = obj1.Read(data, 0, data.Length);
                data_str = Encoding.Default.GetString(data);
                //Console.WriteLine("data_str [" + data_str + "]");

                if (data_str.Contains("THEEND"))
                {
                    ms.Write(data, 0, numBytesRead - 7);
                    total_sizes = total_sizes + numBytesRead - 7;
                    break;
                }
                total_sizes = total_sizes + numBytesRead;
                //writer_stream.Write(data.ToString(), 0, numBytesRead);
                ms.Write(data, 0, numBytesRead);

            } while (numBytesRead == data.Length);

            //logger.Cache(LoggerThreshold.Debug, "numBytesRead " + numBytesRead.ToString());
            //Console.WriteLine("numBytesRead " + numBytesRead.ToString());
            TcpipServerService.GlobalClass.WriteToFile("numBytesRead " + numBytesRead.ToString());

            //Write the client send file to master server
            using (FileStream file = new FileStream(obj[1], FileMode.Create, System.IO.FileAccess.Write))
            {
                ms.WriteTo(file);
                ms.Close();
            }

            //print_log(logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]c_transferFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + total_sizes.ToString() + "]");
            //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]c_transferFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + total_sizes.ToString() + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]c_transferFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + total_sizes.ToString() + "]");
            //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]c_transferFunc finished transfered from [" + ws_rmt_info + "] Total sizes [" + total_sizes.ToString() + "]");
             
        }

        private static void SleepFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            //Console.WriteLine("SleepFunc");
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString() + "T" + thread_id;

            //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]SleepFunc receive [sleep] from [" + ws_rmt_info + "]");
        }

        private static void WhoamiFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            //Console.WriteLine("WhoamiFunc");
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();
            
            byte[] sendBuffer = Encoding.UTF8.GetBytes(ws_rmt_info+"T"+thread_id);
            //byte[] sendBuffer = Encoding.UTF8.GetBytes(output);
            //networkStream.Write(sendBuffer, 0, sendBuffer.Length);

            //Console.WriteLine("Local ["+ lcl_local_ip+"]T["+thread_id+"][SyncServer]WhoamiFunc wrote [" + ws_rmt_info + "]");
            obj1.Write(sendBuffer, 0, sendBuffer.Length);
            //Thread.Sleep(300);
            //print_log(logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]WhoamiFunc wrote [" + ws_rmt_info + "T" + thread_id + "] to [" + ws_rmt_info + "]");
            //Console.WriteLine("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]WhoamiFunc wrote [" + ws_rmt_info + "] to [" + ws_rmt_info + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]WhoamiFunc wrote [" + ws_rmt_info + "] to [" + ws_rmt_info + "]");
        }

        private static void RunBatchFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();

            var time = DateTime.Now;
            string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");

            TcpipServerService.GlobalClass.WriteToFile("[SyncServer]RunBatchFunc [" + obj[1] + "] [" + obj[2] + "][" + obj[3] + "]");
            //Console.WriteLine("[SyncServer]RunBatchFunc [" + obj[1] + "] [" + obj[2] + "][" + obj[3] + "]");
            string lcl_run_result;
            //RunResults runResults = RunExecutable(obj[0], obj[1] + " " + obj[2], ".");
            RunResults runResults = RunExecutable(obj[1], obj[2] + " " + obj[3], ".");
            if (runResults.RunException != null)
            {
                //Console.WriteLine(runResults.RunException);
                lcl_run_result = runResults.RunException.ToString();
            }
            else
            {
                //Console.WriteLine("Output");
                //Console.WriteLine("======");
                //Console.WriteLine(runResults.Output);
                //Console.WriteLine("Error");
                //Console.WriteLine("=====");
                //Console.WriteLine(runResults.Error);
                lcl_run_result = runResults.Output.ToString();
            }

            if (connection != null)
            {
                string sql = "insert into log_tbl ([session_id], [Third_party_id], [task_id], [desktop_id], [Desktop_ret_result], [server_ret_status], [desktop_status]) values (@session_id, @third_party_id, @task_id, @desktop_id, @desktop_ret_result, @server_ret_status, @desktop_status)";
                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    //Segregate desktop id from process name
                    //process name + desktopid + timeout + invoke_cnt + max_cnt + desktop_seq_no + task_seq_no
                    string[] process_split = processname.Split('_');

                    //Console.WriteLine("processname in RunBatchFunc [" + processname + "][" + runResults.ExitCode.ToString()+"]");
                    TcpipServerService.GlobalClass.WriteToFile("processname in RunBatchFunc [" + processname + "][" + runResults.ExitCode.ToString() + "]");

                    cmd.Parameters.AddWithValue("@session_id", process_split[0] + "_" + process_split[6] + "_" + process_split[1] + "_" + formattedTime);
                    cmd.Parameters.AddWithValue("@third_party_id", process_split[0]);
                    cmd.Parameters.AddWithValue("@server_ret_status", runResults.ExitCode.ToString());
                    cmd.Parameters.AddWithValue("@desktop_status", DBNull.Value);
                    cmd.Parameters.AddWithValue("@task_id", process_split[6]);
                    cmd.Parameters.AddWithValue("@desktop_id", process_split[1]);
                    cmd.Parameters.AddWithValue("@desktop_ret_result", lcl_run_result);
                    cmd.ExecuteNonQuery();
                }
            }

            byte[] sendBuffer = Encoding.UTF8.GetBytes(lcl_run_result);
            obj1.Write(sendBuffer, 0, sendBuffer.Length);
            //Thread.Sleep(300);
            //print_log(logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]RunBatchFunc wrote [" + lcl_run_result.Trim() + "] to [" + ws_rmt_info + "]");
            TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]RunBatchFunc wrote [" + lcl_run_result.Trim() + "] to [" + ws_rmt_info + "]");

            //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]RunBatchFunc wrote [" + lcl_run_result.Trim() + "] to [" + ws_rmt_info + "]");

        }

        private static void LocalRunBatchFunc(string[] obj, NetworkStream obj1, TcpClient tcpclient, string thread_id, string lcl_local_ip, ILogger logger, SqlConnection connection, string processname, StreamReader reader)
        {
            //logger.Cache(LoggerThreshold.Debug, "[SyncServer]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "][" + obj[2] + "]");
            //Console.WriteLine("[SyncServer]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "][" + obj[2] + "]");
            TcpipServerService.GlobalClass.WriteToFile("[SyncServer]LocalRunBatchFunc [" + obj[0] + "] [" + obj[1] + "][" + obj[2] + "]");

            string ws_rmt_info = tcpclient.Client.RemoteEndPoint.ToString();
            var result = new StringBuilder();
            var readBuffer = new byte[256];
            //var totalBytes = 0;
            byte[] sendBuffer = Encoding.UTF8.GetBytes("Hello");

            //Console.WriteLine("obj[0] [" + obj[0] + "]");

            if (obj[0] == "JS")
            {
                string reader_string;
                reader_string = reader.ReadLine();

                TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + reader_string.Trim() + "] from [" + ws_rmt_info + "]");
                //Console.WriteLine("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + reader_string.Trim() + "] from [" + ws_rmt_info + "]");
                //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + reader_string.Trim() + "] from " + ws_rmt_info);

                //obj1.Write(sendBuffer, 0, sendBuffer.Length);
                //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc send [" + ws_rmt_info + "] to " + ws_rmt_info);
            }
            else
            {
                var oth_result = new StringBuilder();
                var oth_readBuffer = new byte[256];
                var totalBytes = 0;

                do
                {
                    var bytesRead = obj1.Read(oth_readBuffer, 0, oth_readBuffer.Length);
                    oth_result.Append(Encoding.UTF8.GetString(oth_readBuffer, 0, bytesRead));
                    totalBytes += bytesRead;
                }
                while (tcpclient.Available > 0);
                /*
                reader = new StreamReader(obj1);
                string reader_string;
                reader_string = reader.ReadLine();
                */

                //print_log(logger, " Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + oth_result.ToString().Trim() + "] from [" + ws_rmt_info + "]");
                //Console.WriteLine(" Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + oth_result.ToString().Trim() + "] from [" + ws_rmt_info + "]");
                TcpipServerService.GlobalClass.WriteToFile("Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + oth_result.ToString().Trim() + "] from [" + ws_rmt_info + "]");
            }

            //Console.WriteLine("LocalRunBatchFunc [" + reader_string + "]");
            //logger.Cache(LoggerThreshold.Debug, "LocalRunBatchFunc readLine [" + reader_string + "]");
            /*
            do
            {
                var bytesRead = obj1.Read(readBuffer, 0, readBuffer.Length);
                result.Append(Encoding.UTF8.GetString(readBuffer, 0, bytesRead));
                totalBytes += bytesRead;
            }
            while (obj1.DataAvailable);
            */

            //if (reader_string == "" || reader_string == null)
            //{
            //}
            //else
            //{
                //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + reader_string.ToString().Trim() + "] from [" + ws_rmt_info + "]");
                //logger.Cache(LoggerThreshold.Debug, "Local [" + lcl_local_ip + "T" + thread_id + "][SyncServer]LocalRunBatchFunc get [" + result.ToString().Trim() + "] from " + ws_rmt_info);
            //}
            //Console.WriteLine("Local ["+lcl_local_ip + "]T["+thread_id+"][SyncServer]LocalRunBatchFunc read ["+ result.ToString().Trim() + "] from "+ ws_rmt_info);
        }

        private static void print_log(ILogger logger, string ws_print_str)
        {
            var time = DateTime.Now;
            string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");
            logger.Cache(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);

        }

        private TcpClient tcpClient;
        private ILogger logger;
        private Func<string, string> workload;
        private SqlConnection connection;
        private string processname;
        private NetworkStream networkstream;
    }
}