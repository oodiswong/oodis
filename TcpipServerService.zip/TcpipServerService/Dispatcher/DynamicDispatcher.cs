﻿using System;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Threading;
using TcpipServerService.Logger;
using TcpipServerService.Server;

using System.Data.SqlClient;

namespace TcpipServerService.Dispatcher
{
    internal class DynamicDispatcher : IDispatcher
    {
        public void Dispatch(TcpListener listener, ILogger logger, Func<string, string> workload, string processname, SqlConnection connection)
        {
            Console.WriteLine("[DynamicDispatcher]Dispatch");
            this.listener = listener;
            this.logger = logger;
            this.threadWorkload = workload;
            this.connection = connection;
            this.processname = processname;

            Thread threadWork = new Thread(new ThreadStart(processThreadQueue));
            threadWork.Start();

            while (true)
            {
                try
                {
                    TcpClient tcpClient = this.listener.AcceptTcpClient();
                    this.queue.Enqueue(tcpClient);
                }
                catch (System.IO.IOException e)
                {
                    this.logger.Log(LoggerThreshold.Error, "Exception = " + e.Message);
                }
            }
        }

        public DynamicDispatcher(int maxWorkers)
        {
            Console.WriteLine("[DynamicDispatcher]DynamicDispatcher");
            this.maxConcurentThreads = new SemaphoreSlim(maxWorkers);
        }

        private void doThreadWork(object objServer)
        {
            Console.WriteLine("[DynamicDispatcher]doThreadWork");
            var server = objServer as SyncServer;
            server.Run();
            this.maxConcurentThreads.Release();
        }

        private void processThreadQueue()
        {
            Console.WriteLine("[DynamicDispatcher]processThreadQueue");
            while (true)
            {
                try
                {
                    TcpClient tcpClient;
                    if (this.queue.TryDequeue(out tcpClient))
                    {
                        this.maxConcurentThreads.Wait();
                        var server = new SyncServer(tcpClient, this.logger, this.threadWorkload, this.connection, this.processname);
                        var workingThread = new Thread(new ParameterizedThreadStart(this.doThreadWork));
                        workingThread.Start(server);
                    }
                    else
                        Thread.Sleep(100);
                }
                catch (System.IO.IOException e)
                {
                    this.logger.Log(LoggerThreshold.Error, "Exception = " + e.Message);
                }
            }
        }

        private Func<string, string> threadWorkload;
        private ConcurrentQueue<TcpClient> queue = new ConcurrentQueue<TcpClient>();
        private SemaphoreSlim maxConcurentThreads;
        private SqlConnection connection;
        private string processname;
        private NetworkStream networkstream;

        private TcpListener listener;
        private ILogger logger;
    }
}