﻿using System;
using System.Net.Sockets;
using System.Threading;
using TcpipServerService.Logger;
using TcpipServerService.Server;

using System.Data.SqlClient;

namespace TcpipServerService.Dispatcher
{
    internal class PoolDispatcher : IDispatcher
    {
        public void Dispatch(TcpListener listener, ILogger logger, Func<string, string> workload, string processname, SqlConnection connection)
        {
            Console.WriteLine("[PoolDispatcher]Dispatch");
            for (int i = 0; i < numThreads; i++)
            {
                ThreadInPool poolThread = new ThreadInPool(listener, logger, workload, connection, processname, null);
                Thread thread = new Thread(new ThreadStart(poolThread.Run));
                thread.Start();
            }
        }

        public PoolDispatcher(int numThreads)
        {
            Console.WriteLine("[PoolDispatcher]PoolDispatcher");
            this.numThreads = numThreads;
        }

        private int numThreads;
    }

    internal class ThreadInPool
    {
        public ThreadInPool(TcpListener listener, ILogger logger, Func<string, string> workload, SqlConnection connection, string processname, NetworkStream networkstream)
        {
            Console.WriteLine("[PoolDispatcher]ThreadInPool");
            this.listener = listener;
            this.logger = logger;
            this.workload = workload;
            this.connection = connection;
            this.processname = processname;
            this.networkstream = networkstream;
        }

        public void Run()
        {
            Console.WriteLine("[PoolDispatcher]Run");
            while (true)
            {
                try
                {
                    TcpClient tcpClient = this.listener.AcceptTcpClient();
                    SyncServer server = new SyncServer(tcpClient, this.logger, this.workload, this.connection, this.processname);

                    Thread thread = new Thread(new ThreadStart(server.Run));
                    thread.Start();
                }
                catch (Exception ex)
                {
                    logger.Log(LoggerThreshold.Error, ex.Message);
                }
            }
        }

        private TcpListener listener;
        private ILogger logger;
        private Func<string, string> workload;
        private SqlConnection connection;
        private string processname;
        private NetworkStream networkstream;
    }
}