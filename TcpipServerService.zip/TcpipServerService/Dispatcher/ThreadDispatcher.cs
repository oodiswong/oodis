﻿using System;
using System.Net.Sockets;
using System.Threading;
using TcpipServerService.Logger;
using TcpipServerService.Server;
using System.Threading.Tasks;
using System.IO;

using System.Data.SqlClient;

namespace TcpipServerService.Dispatcher
{
    internal class ThreadDispatcher : IDispatcher
    {
        //private TcpClient tcpClient;
        public static StreamWriter sw;

        public void Dispatch(TcpListener listener, ILogger logger, Func<string, string> workload, string processname, SqlConnection connection)
        {
            StreamReader reader;
            long ws_invoke_cnt=0;
            long ws_max_cnt=0;
            string ws_timeout="-1";
            int ws_desktop_seq_no=0;
            int ws_task_seq_no = 0;

            //System.Threading.Timer TTimer = null;
            Timer TTimer = null;

            //print_log(logger, " [ThreadDispatcher]Dispatch [" + processname + "]");
            //Console.WriteLine(" [ThreadDispatcher]Dispatch [" + processname + "]");
            //print_log(logger, " [ThreadDispatcher]Dispatch [" + processname + "]");
            TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch [" + processname + "]");
            //logger.Log(LoggerThreshold.Debug, " [ThreadDispatcher]Dispatch [" + processname + "]");
            //logger.Cache(LoggerThreshold.Debug, "[ThreadDispatcher]Dispatch [" + processname + "]");
            int thread_cnt = 0;
            //Thread[] thread = new Thread[1000];            

            while (true)
            {
                try
                {
                    //TcpClient tcpClient = listener.AcceptTcpClient();

                    if (!listener.Pending())
                    {
                        //5000
                        //Thread.Sleep(1000);
                        //Console.WriteLine("Sorry, no connection requests have arrived");
                        //TcpipServerService.GlobalClass.WriteToFile("Sorry, no connection requests have arrived");
                        continue;

                    }
                    else
                    {
                        TcpClient tcpClient = listener.AcceptTcpClient();
                    //}

                    //Console.WriteLine(" [ThreadDispatcher]Dispatch after tcpClient [" + tcpClient.Available.ToString() + "]");
                    //print_log(logger, " [ThreadDispatcher]Dispatch after tcpClient [" + tcpClient.Available.ToString() + "]");
                    TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch after tcpClient [" + tcpClient.Available.ToString() + "]");

                    var networkStream = tcpClient.GetStream();

                    //Console.WriteLine("after GetStream networkstream...");
 
                    reader = new StreamReader(networkStream);
                    //Read the process name + desktop_id from client
                    string reader_string = reader.ReadLine();

                    //print_log(logger, " [ThreadDispatcher]Dispatch after AcceptTcpClient [" + reader_string + "]");
                    //Console.WriteLine(" [ThreadDispatcher]Dispatch after AcceptTcpClient [" + reader_string + "][" + tcpClient.Available.ToString() + "]");
                    TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch after AcceptTcpClient [" + reader_string + "][" + tcpClient.Available.ToString() + "]");

                    //Client send process name + desktopid + timeout + invoke_cnt + max_cnt + desktop_seq_no + task_seq_no
                    string[] processname_desktopid = reader_string.Split('_');
                    //processname = processname_desktopid[0];
                    processname = reader_string;

                    ws_timeout    = processname_desktopid[2];
                    ws_invoke_cnt = Convert.ToInt64(processname_desktopid[3]);
                    ws_max_cnt    = Convert.ToInt64(processname_desktopid[4]);
                    ws_desktop_seq_no = Convert.ToInt16(processname_desktopid[5]);
                    ws_task_seq_no = Convert.ToInt16(processname_desktopid[6]);

                    //Console.WriteLine(" [ThreadDispatcher]Dispatch after AcceptTcpClient [" + reader_string + "]");  
                    SyncServer server = new SyncServer(tcpClient, logger, workload, connection, processname);

                    //Console.WriteLine("[ThreadDispatcher]Dispatch ["+connection.ToString()+"]");
                    //logger.Log(LoggerThreshold.Debug, "[ThreadDispatcher]Dispatch [" + connection.ToString() + "]");
                    TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch");
                    //BEGIN - Get timeout from database
                    if (connection == null || connection.Equals(""))
                    {
                        //logger.Log(LoggerThreshold.Debug, "No database connected...");
                        TcpipServerService.GlobalClass.WriteToFile("No database connected...");
                    }
                    else
                    {
                        var time = DateTime.Now;
                        string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");

                        //Console.WriteLine("formattedtime [" + formattedTime + "]");
                        //Update dektop_tbl with execution date time
                        SqlCommand command = new SqlCommand("update [desktop_tbl] set [execution_date_time] = '" + formattedTime + "'  where ltrim(rtrim(desktop_id)) = '" + processname_desktopid[1].Trim() + "' and desktop_seq_no = "+ ws_desktop_seq_no, connection);

                        //Console.WriteLine("select timeout from task_tbl [" + command.CommandText + "]");
                        TcpipServerService.GlobalClass.WriteToFile("select timeout from task_tbl [" + command.CommandText + "]");

                        SqlDataReader update_reader=null;
                        try
                        {
                            update_reader = command.ExecuteReader();
                        }
                        catch (Exception update_err)
                        {
                            //print_log(logger, " [" + command.CommandText + "] Error [" + update_err.ToString() + "]");
                            //Console.WriteLine(" [" + command.CommandText + "] Error [" + update_err.ToString() + "]");
                            TcpipServerService.GlobalClass.WriteToFile(" [" + command.CommandText + "] Error [" + update_err.ToString() + "]");
                        }
                        update_reader.Close();
                    }
                    //END - get timeout from database

                    //Console.WriteLine("ws_timeout [" + ws_timeout + "]");

                    Thread thread = new Thread(() =>
                    {
                        //if (ws_timeout != "-1")
                        if (ws_timeout != "-1")
                        {
                            //Console.WriteLine("[ThreadDispatcher]Dispatch Setting timeout...");
                            TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch Setting timeout...");

                            //TTimer = new System.Threading.Timer(
                            TTimer = new Timer(
                                new TimerCallback(TickTimer),
                                reader_string,
                                ws_invoke_cnt,
                                ws_max_cnt);
                        }
                        
                        server.Run();
                    });
       
                    thread.Name = tcpClient.Client.RemoteEndPoint.ToString();
                    thread.Start();
                    
                    TcpipServerService.GlobalClass.WriteToFile("[ThreadDispatcher]Dispatch thread.Start...");
                    //Console.WriteLine("[ThreadDispatcher]Dispatch thread.Start...");
                }
                }
                catch (Exception ex)
                {
                    //logger.Log(LoggerThreshold.Error, ex.Message);
                    //print_log(logger, ex.Message);
                    TcpipServerService.GlobalClass.WriteToFile(ex.Message);
                }
                thread_cnt = thread_cnt + 1;
            }

        }

        static void TickTimer(object state)
        {
            //System.Threading.Timer TTimer = null;
            Timer TTimer = null;
            string processname = (string) state;

            var time = DateTime.Now;
            string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");

            TcpipServerService.GlobalClass.WriteToFile("[" + formattedTime + "] Timeout [" + processname + "]");
            //Console.WriteLine("["+formattedTime+"] Timeout [" + processname + "]");
            //Console.WriteLine("thread name [" + Thread.CurrentThread.Name + "]");

            if (processname == "" || processname == null)
            {
                //Console.WriteLine("[" + formattedTime + "] Nothing happen.");
                TcpipServerService.GlobalClass.WriteToFile("[" + formattedTime + "] Nothing happen.");
            }
            else
            {
                //Console.WriteLine("[" + formattedTime + "] Thread to be aborted.");
                TcpipServerService.GlobalClass.WriteToFile("[" + formattedTime + "] Thread to be aborted.");
                /*TTimer.Change(
                    Timeout.Infinite,
                    Timeout.Infinite);
                 */
                //TTimer.Dispose();
                Thread.CurrentThread.Abort();
            }

            TTimer.Change(
                Timeout.Infinite,
                Timeout.Infinite);
        }

        /*private static void print_log(ILogger logger, string ws_print_str)
        {
            var time = DateTime.Now;
            string formattedTime = time.ToString("yyyy/MM/dd hh:mm:ss.fff tt");
            //logger.Cache(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);
            logger.Log(LoggerThreshold.Debug, "[" + formattedTime + "]" + ws_print_str);

        } */

    }
}