﻿using System;
using System.Net.Sockets;
using TcpipServerService.Logger;

using System.Data.SqlClient;

namespace TcpipServerService.Dispatcher
{
    internal interface IDispatcher
    {
        void Dispatch(TcpListener listener, ILogger logger, Func<string, string> workload, string processname, SqlConnection connection);
    }
}