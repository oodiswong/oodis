﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Collections;

using System.Data.SqlClient;
using Timer = System.Timers.Timer;

namespace TcpipServerService
{
   //public partial class Service1 : ServiceBase
    public partial class Service1 : System.ServiceProcess.ServiceBase
    {   
        public static string[] cmd_parameters = new string[256];
        //public static int cmd_num_of_param;
        public static StreamWriter sw;
        public static DateTime m_lastReceiveDateTime;
        public static DateTime m_currentReceiveDateTime;
        public static int gbl_tot_thread = 0;
        static object locker = new object();
        private static int s_threadCount=0;

        private static byte[] m_byBuff = new byte[50];		// Receive data buffer
        private static Thread newThread;

        public Service1(string[] args)
        {
            string[] onstartArgs = Environment.GetCommandLineArgs();
            string[] n_onstartArgs = new string[100];
            Array.Copy(onstartArgs, 1, n_onstartArgs, 0, onstartArgs.Length - 1);

            Options options = parseOptions(n_onstartArgs);

            if (options.ServerVerb.DBConnectionString == "")
            {
                cmd_parameters[1] = "";
            }
            else
            {
                string[] db_connect_string = options.ServerVerb.DBConnectionString.Split(':');
                /*
                cmd_parameters[1] = "TEST-PC"; //MS SQL database server
                cmd_parameters[2] = "Test-pc\\wongls"; //MS SQL user id
                cmd_parameters[3] = "wongls671124"; //MS SQL password
                cmd_parameters[4] = "master"; //MS SQL database name
                */
                cmd_parameters[1] = db_connect_string[0]; //MS SQL database server
                cmd_parameters[2] = db_connect_string[1]; //MS SQL user id
                cmd_parameters[3] = db_connect_string[2]; //MS SQL password
                cmd_parameters[4] = db_connect_string[3]; //MS SQL database name

                //Console.WriteLine("DB Name [" + db_connect_string[3] + "]");
            }

            InitializeComponent();

            //Console.WriteLine("run Service1");

        }

        
        private static Options parseOptions(string[] args)
        {

            string invokedVerb = null;
            object invokedVerbInstance = null;

            var options = new Options();
            if (!CommandLine.Parser.Default.ParseArgumentsStrict(args, options,
              (verb, subOptions) =>
              {
                  invokedVerb = verb;
                  invokedVerbInstance = subOptions;
              }))
            {
                Environment.Exit(CommandLine.Parser.DefaultExitCodeFail);
            }

            if (string.Compare(invokedVerb, "server", true) == 0)
            {
                options.Mode = Mode.Server;
                options.ServerVerb = invokedVerbInstance as ServerSubOptions;
            }
            else
            {
                options.Mode = Mode.Client;
                options.ClientVerb = invokedVerbInstance as ClientSubOptions;
            }

            return options;
        }
        
        protected override void OnStart(string[] args)
        {
            base.OnStart(args);

            string[] onstartArgs = Environment.GetCommandLineArgs();
            string[] n_onstartArgs = new string[100];

            SqlConnection gbl_connection = connect_to_mssql();

            string[] tmp_args = new string[2];

            Array.Copy(onstartArgs, 1, n_onstartArgs, 0, onstartArgs.Length - 1);

            Options options = parseOptions(n_onstartArgs);
            try
            {
                switch (options.Mode)
                {
                    case Mode.Server:
                        Server.Runner serverRunner = new Server.Runner();
                        //temporary hard code the sever and client log file location
                        //serverRunner.Run(options);
                        if (gbl_connection == null)
                        {
                            newThread = new Thread(() => serverRunner.Run(options, gbl_connection, "c:\\8\\OODIS_Server_Log_yyyymmdd.txt", "c:\\8\\OODIS_Client_Log_yyyymmdd.txt"));
                        }
                        else
                        {
                            newThread = new Thread(() => serverRunner.Run(options, gbl_connection, "c:\\8\\DBOODIS_Server_Log_yyyymmdd.txt", "c:\\8\\DBOODIS_Client_Log_yyyymmdd.txt"));
                        }
                        //newThread.Start(options);
                        int mainThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId;
                        Console.WriteLine("[Service1]OnStart mainthreadid [" + mainThreadId.ToString() + "]");
                        newThread.Start();
                        Console.WriteLine("after newthread.start...");
                        break;
                    //temporary mask off begin
                    //case Mode.Client:
                        //Client.Runner clientRunner = new Client.Runner();                           
                        //clientRunner.Run(options); //return clientRunner.Run(options);
                        //break;
                    //temporary mask off end
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }            
        }

        protected override void OnStop()
        {
            TcpipServerService.GlobalClass.WriteToFile("Service is stopped.");
            //Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Service is stopped.");
            //this.server.StopServer();
            //server.StopServer();
            //m_serverThread.Abort();
            //listener.Shutdown(SocketShutdown.Both);
            //listener.Close();
            newThread.Abort();
        }

        public SqlConnection connect_to_mssql()
        {
            // Build connection string
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            SqlConnection connection=null;

            if (cmd_parameters[1] != "")
            {
                builder.DataSource = cmd_parameters[1];
                builder.UserID = cmd_parameters[2];
                builder.Password = cmd_parameters[3];
                builder.InitialCatalog = cmd_parameters[4];

                try
                {
                    // Connect to SQL
                    Console.WriteLine("Connecting to SQL Server ... ");

                    string db_connect_str = "Server=" + cmd_parameters[1] + ";Database=" + cmd_parameters[4] + ";Trusted_Connection=Yes";
                    connection = new SqlConnection(db_connect_str);
                    {
                        connection.Open();
                        //Console.WriteLine("Done.");
                        Console.WriteLine("[" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss.fff tt") + "] Connection to database SUCCESS.");
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine(e.ToString());
                    TcpipServerService.GlobalClass.WriteToFile("Connection to database failed " + e.ToString());
                    //Console.WriteLine("Connection to database failed " + e.ToString());
                }
            }
            return connection;
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            //WriteToFile("Service is recall at " + DateTime.Now);
        }
        private static void WriteToFile(string Message)
        {
            //string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            string path = "c:\\8\\";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            //string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\OODIS_Server_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            string filepath = "c:\\8\\OODIS_Server_Log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
            if (!File.Exists(filepath))
            {
                // Create a file to write to.   
                //using (StreamWriter sw = File.CreateText(filepath))
                using (sw = File.CreateText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
            else
            {
                //using (StreamWriter sw = File.AppendText(filepath))
                using (sw = File.AppendText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
        }

        //TRANSFER file command

        // State object for reading client data asynchronously  
        public class StateObject
        {
            // Client  socket.  
            public Socket workSocket = null;
            // Size of receive buffer.  
            public const int BufferSize = 1024;
            // Receive buffer.  
            public byte[] buffer = new byte[BufferSize];
            // Received data string.  
            public StringBuilder sb = new StringBuilder();
        }

        // Thread signal.  
        public static ManualResetEvent allDone = new ManualResetEvent(false);

        public static void AcceptCallback(IAsyncResult ar)
        {
            Console.WriteLine(s_threadCount.ToString()+" [AcceptCallback]");

            try
            {
                // Signal the main thread to continue.  
                //allDone.Set();

                // Get the socket that handles the client request.  
                Socket listener = (Socket)ar.AsyncState;

                Socket handler = listener.EndAccept(ar);

                string act_thread = Thread.CurrentThread.ManagedThreadId.ToString().ToString();
                Console.WriteLine("[AcceptCallback]Connected ? " + listener.Connected.ToString());

                //while (true)
                //{
                    //allDone.Reset();

                    // Create the state object.  
                    StateObject state = new StateObject();
                //state.workSocket = handler;

                Console.WriteLine("before execute beginaccept");
                    //NewConnection(listener.EndAccept(ar));
                    //listener.BeginAccept(new AsyncCallback(ReadCallback), listener);
                Console.WriteLine("after execute beginaccept");

                handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                    new AsyncCallback(ReadCallback), state); 


                //Console.WriteLine(act_thread + " after beginreceive " + System.Text.Encoding.Default.GetString(state.buffer) + "]");
                //allDone.WaitOne();       

                /*
                if (!allDone.WaitOne(60000))
                {
                    try
                    {
                        handler.Close();
                    }
                    catch
                    {
                        Console.WriteLine("[AcceptCallback] 60000 WaitOne");
                    }
                }
                */
                //}
            }
            catch (Exception conn_err)
            {
                //sock_disconnect = 1;
                Console.WriteLine(Thread.CurrentThread.ManagedThreadId.ToString()+" Client disconnected. " + conn_err.ToString());
                //Thread.CurrentThread.Abort();               
                //listener.Close();
            }
        }
     
        public static void ReadCallback(IAsyncResult ar)
        {
            Console.WriteLine(s_threadCount.ToString()+" [ReadCallback]");

            Console.WriteLine("IAsyncResult ["+ar.IsCompleted.ToString()+"]["+ar.CompletedSynchronously.ToString()+"]["+Thread.CurrentThread.IsThreadPoolThread.ToString()+"]");

            // Retrieve the state object and the handler socket  
            // from the asynchronous state object.  
            StateObject state = (StateObject)ar.AsyncState;
            Socket handler = state.workSocket;

            /*
            if (sock_disconnect == 1)
            {
                Console.WriteLine("[ReadCallback]sock disconnected");
                Thread.CurrentThread.Abort();
                handler.Close();

                return;
            }
            */

            //allDone.Set();

            String content = String.Empty;
            string read_thread = Thread.CurrentThread.ManagedThreadId.ToString().ToString();

            int bytesRead;
            byte[] byReturn;
            try
            {
                //StateObject theSockId = (StateObject)ar.AsyncState;

                Console.WriteLine("before endreceive");

                bytesRead = 0;
                try
                {
                    // Read data from the client socket.   
                    bytesRead = handler.EndReceive(ar);
                }
                catch (Exception by_err)
                {
                    Console.WriteLine("endreceive error "+by_err.ToString());
                }

                content = state.sb.ToString();
                Console.WriteLine("READ CONTENT " + content.ToString());

                byReturn = new byte[bytesRead];
                Array.Copy(state.buffer, byReturn, bytesRead);
            }
            catch (SocketException ex)
            {
                Console.WriteLine("Socket Exception ["+ex.ToString()+"]");
                return;
            }

            Console.WriteLine("endReceive byte ["+bytesRead.ToString()+"]["+ byReturn.Length.ToString()+"]");

            if (byReturn.Length < 1)
            {
                Console.WriteLine("Client {0}, disconnected", handler.RemoteEndPoint);
                handler.Close();
                return;
            }

            if (bytesRead > 0)
            {
               // There  might be more data, so store the data received so far.  
               state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));

               // Check for end-of-file tag. If it is not there, read   
               // more ta.  
               content = state.sb.ToString();
               Console.WriteLine("READ CONTENT " + content.ToString());

               if (content.IndexOf("<EOF>") > -1)
               {
                  // All the data has been read from the   
                  // client. Display it on the console.  
                  Console.WriteLine(read_thread+" Read {0} bytes from socket. \n Data : {1}",
                     content.Length, content);

                    if (content.IndexOf("where<EOF>") > -1)
                    {
                        // Echo the data back to the client.  
                        Send(handler, content);
                    }
               }
               else
               {
                  Console.WriteLine("else in [ReadCallback]");

                  // Not all data received. Get more.  
                  handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                  new AsyncCallback(ReadCallback), state);
               }

            }
            else
            {
                Console.WriteLine("bytesRead <0");
            }
        }

        private static void Send(Socket handler, String data)
        {
            string send_thread = Thread.CurrentThread.ManagedThreadId.ToString().ToString();

            Console.WriteLine(send_thread+" [Send] "+ s_threadCount.ToString());
            // Convert the string data to byte data using ASCII encoding.  
            byte[] byteData = Encoding.ASCII.GetBytes(data);
            string rmt_ip = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+handler.RemoteEndPoint.ToString();
            Console.WriteLine(send_thread+" data to send [" + System.Text.Encoding.Default.GetString(byteData)+"]"+ rmt_ip);
            byteData = Encoding.ASCII.GetBytes(rmt_ip);

            // Begin sending the data to the remote device.  
            handler.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCallback), handler);
        }

        private static void SendCallback(IAsyncResult ar)
        {
            string sendcall_thread = Thread.CurrentThread.ManagedThreadId.ToString().ToString();

            Console.WriteLine(sendcall_thread+" [SendCallback] "+ s_threadCount.ToString());
            try
            {
                // Retrieve the socket from the state object.  
                Socket handler = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = handler.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);

                //handler.Shutdown(SocketShutdown.Both);
                //handler.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
    
}

